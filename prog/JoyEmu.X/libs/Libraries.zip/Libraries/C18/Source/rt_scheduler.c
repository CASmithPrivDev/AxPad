/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 3                                              $:  Revision of last commit
//  $Author:: reneleonrichard                             $:  Author of last commit
//  $Date:: 2011-07-27 17:54:46 -0400 (Wed, 27 Jul 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Source/rt_scheduler.c $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************

#include <pt.h>
#include <timers.h>
#include <rt_scheduler.h>
#include <uart_driver.h>

//**************************************************************
//place internal function prototypes here
//**************************************************************
void low_isr(void);
void high_isr(void);

static unsigned char rt_taskSort(void);
static void rt_taskRunner(void);
static PT_THREAD(idleTask(struct pt *pt));

//**************************************************************
//place static constants here
//**************************************************************
#pragma romdata

char rt_schedulerRev[14] = {"$Rev:: 3   $:"};
unsigned int tmr0_count_reset = (0xFFFF - TMR0_TICK_VALUE);

//**************************************************************
//place unitialized variables here
//**************************************************************
#pragma udata

/* variable for system time */
unsigned int ticks;

/* container for task states */
struct rt_taskState{
	unsigned int runCnt;
	unsigned int yieldCnt;
	unsigned int timeOutCnt;	//how many YIELDS before a timeout error is thrown
	unsigned char status;
	union {
		struct{
			unsigned scheduled	:1;    	//scheduled from main program, task will run on next iteration
			unsigned fastSch 	:1;		//scheduled from ISR, task will run on next loop in current iteration
			unsigned timeOut  	:1;
			unsigned timeOutErr :1;
			unsigned 			:4;
		}bits;
		unsigned char byte; 
	}flags;
	char name[TASKNAMELENGTH];
};
struct rt_taskState taskState[NUMOFTASKS];
struct pt *ptTask[NUMOFTASKS];
unsigned char fastSchFlag;

/* declare array of pointers for tasks */
ptr2Task taskPtr[NUMOFTASKS];
ptr2Task taskQueue[NUMOFTASKS];
unsigned char taskQueueID[NUMOFTASKS];

/* variables for OS main loop */
unsigned char taskNumActive;

/* resources lock bits, should be part of driver file */
union {
	struct{
		unsigned I2C1  	:1;
		unsigned I2C2  	:1;
		unsigned UART1 	:1;
		unsigned UART2 	:1;
		unsigned 		:4;
	}bits;
	unsigned char byte; 
}rt_locks;

static struct pt idleTask_pt;

//**************************************************************
//place initialized variables here
//**************************************************************
#pragma idata


//**************************************************************
//place macros here
//**************************************************************

//**************************************************************
//All code below this line should be functions only
#pragma code

//**************************************************************
//SUPPORTING FUNCTIONS START HERE
//**************************************************************
//FUNCTION NAME:	rt_taskInit
//ARGUMENTS:        func: 		pointer to PT_THREAD implementing this task
//					*pt: 		pointer to pt struct for PT_THREAD
//					freq: 		defined how often the task should be executed
//					priority:	task priority
//RETURNS:          taskID:     when succesful, returns an ID to the task by which the main program can schedule the task 
//DESCRIPTION:      initializes a task and sets up its priority 
//**************************************************************
unsigned char rt_taskInit(ptr2Task func, 
						struct pt *pt,
						const char *strName)
{
	unsigned char ret;
	unsigned char i;
	
	if (taskNumActive >= NUMOFTASKS){
		ret = MAXTASKNUM;
	}else{
		PT_INIT(pt);
		/* store pointer to task */
		taskPtr[taskNumActive] = func;
		/* store pointer to pt and priority */
		ptTask[taskNumActive] = pt;
		taskState[taskNumActive].status = INIT;
		taskState[taskNumActive].flags.byte = 0;
		for( i=0 ; i<TASKNAMELENGTH ; i++ )
		{
			taskState[taskNumActive].name[i] = *(strName++);
		}
		ret = taskNumActive++;
	}
	return ret;
}

//**************************************************************
//FUNCTION NAME:	rt_taskKill
//ARGUMENTS:        taskID:	ID number of task to kill, ID number returned with rt_taskInit
//					cmd:	
//RETURNS:           
//DESCRIPTION:      should be used to remove ALWAYS tasks
//**************************************************************
unsigned char rt_taskKill(unsigned char taskID, unsigned char forceKill)
{
	unsigned char ret;
	
	switch(taskState[taskID].status)
	{
		case DEAD:
			ret = TASKDEAD;
			break;
		case YIELDING:
			/* if forceKill == 1, fall through to kill statements */
			if(!forceKill){
				ret = TASKYIELDING;
				break;
			}
		case COMPLETED:
		case INIT:
		case TIMEOUT:
			taskState[taskID].freq = 0;
			taskState[taskID].status = INIT;
			taskState[taskID].flags.byte = 0;
			PT_INIT(ptTask[taskID]);
			ret = TASKKILLED;
			break;
		default:
			ret = ERROR;
			break;
	}
	return ret;
}

//**************************************************************
//FUNCTION NAME:	rt_taskSchedule
//ARGUMENTS:        taskID:	ID number of task to schedule, ID number returned with rt_taskInit
//					timeOutCnt:	defines how many OS ticks before task is halted.
//RETURNS:           
//DESCRIPTION:      schedules a task to run on the next iteration of the scheduler, call from main program
//**************************************************************
unsigned char rt_taskSchedule(unsigned char taskID,
							unsigned int timeOut)
{
	unsigned char ret;
	
	switch(taskState[taskID].status)
	{
		case DEAD:
			ret = TASKDEAD;
			break;
		case YIELDING:
			ret = TASKYIELDING;
			break;
		case COMPLETED:
		case TIMEOUT:
		case INIT:
			taskState[taskID].yieldCnt = 0;
			taskState[taskID].flags.bits.scheduled = 1;
			if( timeOut == 0 )
			{
				taskState[taskID].flags.bits.timeOut = 0;
				taskState[taskID].flags.bits.timeOutErr = 0;
			}else{
				taskState[taskID].flags.bits.timeOut = 1;
				taskState[taskID].timeOutCnt = timeOut;
			}
			ret = TASKSCHEDULED;
			break;
		default:
			ret = ERROR;
			break;
	}
	return ret;
}

//**************************************************************
//FUNCTION NAME:	rt_taskScheduleFast
//ARGUMENTS:        taskID:	ID number of task to schedule, ID number returned with rt_taskInit
//					timeOutCnt:	defines how many OS ticks before task is halted.
//RETURNS:           
//DESCRIPTION:      schedules a task to run on the next loop of the current iteration, call from ISR
//**************************************************************
unsigned char rt_taskScheduleFast(unsigned char taskID,
								unsigned int timeOut)
{
	unsigned char ret;
	
	switch(taskState[taskID].status)
	{
		case DEAD:
			ret = TASKDEAD;
			break;
		case YIELDING:
			ret = TASKYIELDING;
			break;
		case COMPLETED:
		case TIMEOUT:
		case INIT:
			taskState[taskID].yieldCnt = 0;
			taskState[taskID].flags.bits.fastSch = 1;
			fastSchFlag = 1;
			if( timeOut == 0 )
			{
				taskState[taskID].flags.bits.timeOut = 0;
				taskState[taskID].flags.bits.timeOutErr = 0;
			}else{
				taskState[taskID].flags.bits.timeOut = 1;
				taskState[taskID].timeOutCnt = timeOut;
			}
			ret = TASKSCHEDULED;
			break;
		default:
			ret = ERROR;
			break;
	}
	return ret;
}

//**************************************************************
//FUNCTION NAME:	rt_taskSort
//ARGUMENTS:        
//RETURNS:          taskQueueSize: returns the number of tasks to run in the queue 
//DESCRIPTION:      places the currently scheduled tasks in a queue for execution 
//**************************************************************
static unsigned char rt_taskSort(void)
{
	static unsigned char i;
	unsigned char j = taskQueueSize;
	/* schedule tasks */
	for( i=0 ; i<NUMOFTASKS ; i++ )
	{
		/* Both new tasks and YIELDING tasks have the scheduled bit == 1 */
		if( (taskState[i].flags.bits.scheduled == 1) )
		{
			/* check if this task has already YIELDED in a previous iteration, i.e. not a new task */
			if( taskState[i].status == YIELDING )
			{
				/* has timeout been reached AND is timeout enabled */
				if( taskState[i].flags.bits.timeOut == 1 )
				{
					if( ++taskState[i].yieldCnt >= taskState[i].timeOutCnt )
					{
						taskState[i].status = TIMEOUT;
						taskState[i].flags.bits.timeOutErr = 1;
						taskState[i].flags.bits.scheduled = 0;
						/* reinitialize pt for this task for next entry */
						PT_INIT(ptTask[i]);		
					}
				}else{
				/* else reschedule the YIELDING task */
					taskQueue[j] = taskPtr[i];
					taskQueueID[j++] = i;
				}
			}else{
				/* else schedule the new task */
				taskQueue[j] = taskPtr[i];
				taskQueueID[j++] = i;
				taskState[i].status = YIELDING;
			}
		}
	}
	return j;
}

//**************************************************************
//FUNCTION NAME:	rt_taskRunner
//ARGUMENTS:        none
//RETURNS:          none
//DESCRIPTION:      runs all scheduled tasks which are currentl YIELDING
//**************************************************************
static void rt_taskRunner(void)
{
	unsigned char taskResult;
	
	/* call tasks which are currently YIELDING, I don't use the scheduled flag here
	** because task calling should be synchronous to the OS tick. This way a scheduled
	** task will run on the next iteration loop */
	if ( taskState[taskQueueID[iTask]].status == ( YIELDING ) )
	{
		/* call task, check whether task has completed or has YIELDED */
		taskResult = (*taskQueue[iTask])(ptTask[taskQueueID[iTask]]);	
		
		/* don't look for PT_EXITED, means that applications must end with PT_END */
		if ( ( taskResult == PT_ENDED ) /* || ( taskResult == PT_EXITED ) */ )
		{
			/* mark tasks COMPLETED */
			taskState[taskQueueID[iTask]].status = COMPLETED;
			taskState[taskQueueID[iTask]].yieldCnt = 0;
			taskState[iTask].flags.bits.scheduled = 0;
			/* track how often task executes, remove for release  */
			taskState[taskQueueID[iTask]].runCnt++;
		}
	}
	/* call tasks round robin fashion */
	if ( ++iTask >= taskQueueSize )
	{
		iTask = 0;
	}
}

//**************************************************************
//FUNCTION NAME:	rt_startOS
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
void rt_startOS(void)
{
	unsigned char taskQueueSize;
	unsigned char iTask;
	unsigned char loop;	
	
	while(1)
	{
		loop = 1;
		iTask = 0;
		
		taskQueueSize = rt_taskSort();
		while(loop)
		{
			rt_taskRunner();
			idleTask(&idleTask_pt);

			if( fastSchFlag == 1 )
			{
				/* add fast tasks from ISR */	
			}
		}
	}
}

//**************************************************************
//FUNCTION NAME:    idleTask   
//ARGUMENTS:        pt
//RETURNS:          pt
//DESCRIPTION:      idleTask, times the next task loop
//**************************************************************
static PT_THREAD(idleTask(struct pt *pt))
{
	PT_BEGIN(pt);
		WAIT_FOR_MS(RT_TICK_MS-1);
		/* restart loop, will call rt_taskSort() again */
		loop = 0;
	PT_END(pt);
}

//**************************************************************
//FUNCTION NAME:	rt_Init
//ARGUMENTS:        
//RETURNS:           
//DESCRIPTION:       
//**************************************************************
void rt_init(void)
{
	unsigned char i;

	/* All processor specific code should be in a seperate file */
	/* init timer0 for ticks */
	OpenTimer0(	TIMER_INT_ON & 
				T0_16BIT & 
				T0_SOURCE_INT & 
				T0_PS_1_1);
	INTCON2bits.TMR0IP = 1;
	INTCONbits.TMR0IE = 1;

	/* init idle task */
	PT_INIT(&idleTask_pt);
	ticks = 0;
	
	/* init OS loop variables */
	taskNumActive = 0;
	taskQueueSize = 0;
	fastSchFlag = 0;
	
	/* release all resource locks */
	rt_locks.byte = FREE;
	
	/* clear task queue and task data */
	for ( i=0 ; i<NUMOFTASKS ; i++ )
	{
		taskQueue[i] = 0;
		taskPtr[i] = 0;
		taskState[i].status = DEAD;
		taskState[i].flags.byte = 0;
		taskState[i].runCnt = 0;
		taskState[i].yieldCnt = 0;
		taskState[i].timeOutCnt = 0;
	}
}

//**************************************************************
//INTERRUPTS
//**************************************************************
#pragma code low_vector=0x18
void interrupt_at_low_vector(void)
{
_asm GOTO low_isr _endasm
}
#pragma code /* return to the default code section */
#pragma interruptlow low_isr
void low_isr (void)
{

}

#pragma code high_vector=0x08
void interrupt_at_high_vector(void)
{
_asm GOTO high_isr _endasm
}
#pragma code /* return to the default code section */
#pragma interrupt high_isr
void high_isr (void)
{
	INTCONbits.GIEH = 0;

	if( (PIR1bits.RCIF == 1) && (PIE1bits.RCIE == 1) ){
		uart_rx_callback();
	}
	if( (PIR1bits.TXIF == 1) && (PIE1bits.TXIE == 1) ){
		uart_tx_callback();
	}
	if( (INTCONbits.TMR0IE == 1) && (INTCONbits.TMR0IF == 1) ){
		INTCONbits.TMR0IF = 0;
		WriteTimer0(tmr0_count_reset);
		ticks++;
	}

	RCONbits.IPEN = 1;        //enable priority levels on interrupts
	INTCONbits.GIEH = 1;      //enable high priority interrupts
}