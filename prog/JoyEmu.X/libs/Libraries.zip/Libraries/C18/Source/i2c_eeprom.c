
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 79                                             $:  Revision of last commit
//  $Author:: rrichard                                    $:  Author of last commit
//  $Date:: 2011-12-14 14:14:42 -0500 (Wed, 14 Dec 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Source/i2c_eeprom.c $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************

//#include <p18f4620.h>

#include <i2c_eeprom.h>
#include <i2c.h>

//**************************************************************
//static constants
//**************************************************************
#pragma romdata

//**************************************************************
//unitialized variables
//**************************************************************
#pragma udata

//**************************************************************
//place initialized variables here
//**************************************************************
#pragma idata

//**************************************************************
//internal function prototypes here
//**************************************************************


//**************************************************************
//All code below this line should be functions only
#pragma code

//**************************************************************
//SUPPORTING FUNCTIONS START HERE
//**************************************************************
//FUNCTION NAME:    i2cEepromReadByte
//ARGUMENTS:        char devID - control byte plus address pins of the eeprom
//					unsigned int address - address of operation
//					char *data - pointer to data
//RETURNS:          char - returns result of operation:
//DESCRIPTION:      initializes the eeprom driver
//**************************************************************
char i2cEepromReadByte(char devID, unsigned int address, char *data)
{
	char result = 0;

	StartI2C();
	if ( (WriteI2C(devID | I2C_WRITE)) == NACK )
	{
		/* check if EEPROM acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C((char)(address>>8));
		WriteI2C((char)address);
		RestartI2C();
		WriteI2C(devID | I2C_READ);
		*data = ReadI2C();
		NotAckI2C();
	}
	StopI2C();
	return result;
}

//**************************************************************
//FUNCTION NAME:    i2cEepromReadPage
//ARGUMENTS:        char devID - control byte plus address pins of the eeprom
//					unsigned int address - address of operation
//					char *data - pointer to data
//					char pageSize - length of data to read
//RETURNS:          char - returns result of operation:
//DESCRIPTION:      read up to 256 bytes of eeprom data
//**************************************************************
char i2cEepromReadPage(char devID, unsigned int address, char *data, unsigned char pageSize)
{
	char result = 0;
	char i;

	StartI2C();
	if ( (WriteI2C(devID | I2C_WRITE)) == NACK )
	{
		/* check if EEPROM acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C((char)(address>>8));
		WriteI2C((char)address);
		RestartI2C();
		WriteI2C(devID | I2C_READ);
		for(i=0;i<(pageSize-1);i++)
		{
			*(data++) = ReadI2C();
			AckI2C();
		}
		*data = ReadI2C();
		NotAckI2C();
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    i2cEepromWriteByte
//ARGUMENTS:        char devID - control byte plus address pins of the eeprom
//					unsigned int address - address of operation
//					char *data - pointer to data
//RETURNS:          char - returns result of operation:
//DESCRIPTION:      writes a byte of data to the EEPROM
//					this function does not loop until the write is done
//					code in main should be careful to check that the write
//					is complete before proceeding to other EEPROM tasks
//**************************************************************
char i2cEepromWriteByte(char devID, unsigned int address, char *data)
{
	char result = 0;

	StartI2C();
	if ( (WriteI2C(devID | I2C_WRITE)) == NACK )
	{
		/* check if EEPROM acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C((char)(address>>8));
		WriteI2C((char)address);
		WriteI2C(*data));
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    i2cEepromWritePage
//ARGUMENTS:        char devID - control byte plus address pins of the eeprom
//					unsigned int address - address of operation
//					char *data - pointer to data
//RETURNS:          char - returns result of operation:
//DESCRIPTION:      writes a page of data to the EEPROM
//					this function does not loop until the write is done
//					code in main should be careful to check that the write
//					is complete before proceeding to other EEPROM tasks
//**************************************************************
char i2cEepromWritePage(char devID, unsigned int address, char *data, unsigned char pageSize){

	char i;
	char result = 0;

	StartI2C();
	if ( (WriteI2C(eeprom.control[id] | I2C_WRITE)) == NACK )
	{
		/* check if EEPROM acknowledged */
		result = -1;
	}else
	{
		WriteI2C((char)(address>>8));
		WriteI2C((char)address);
		for(i=0;i<pageSize;i++)
		{
			if( (WriteI2C(*(data++))) == NACK )
			{
				/* check if EEPROM acknowledged */
				result = -1;
				break;
			}
		}
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    i2cEepromIsWriteDone
//ARGUMENTS:        char devID - control byte plus address pins of the eeprom
//RETURNS:          char - returns result of operation:
//DESCRIPTION:      checks if the eeprom ACK's after a write sequence
//**************************************************************
char i2cEepromIsWriteDone(char devID)
{
	char result = 1;

	StartI2C();
	if ( (WriteI2C(devID | I2C_WRITE)) == NACK )
	{
		/* check if EEPROM acknowledged */
		result = -1;
	}else
	{
		StopI2C();
	}
	return result;
}	

