
//  $Rev:: 33                                             $:  Revision of last commit
//  $Author:: rrichard                                    $:  Author of last commit
//  $Date:: 2011-09-14 10:58:04 -0400 (Wed, 14 Sep 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Headers/init_p18f4620.h $
//
//*************************************************************
//defines, includes, enums here
//**************************************************************

#include <GenericTypeDefs.h>

#ifndef  INIT_P18F4620_H
#define  INIT_P18F4620_H

//**************************************************************
//external function prototypes
//**************************************************************
void init_device(void (*_initFuncPtr)(void));

#endif /* HEADER_H */