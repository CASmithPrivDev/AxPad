
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 77                                             $:  Revision of last commit
//  $Author:: rrichard                                    $:  Author of last commit
//  $Date:: 2011-12-14 11:49:54 -0500 (Wed, 14 Dec 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Source/debounce.c $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************

#include <p18cxxx.h>
#include <GenericTypeDefs.h>

#include <debounce.h>

//**************************************************************
//static constants
//**************************************************************
#pragma romdata

//**************************************************************
//unitialized variables
//**************************************************************
#pragma udata


//**************************************************************
//place initialized variables here
//**************************************************************
#pragma idata

//**************************************************************
//internal function prototypes here
//**************************************************************


//**************************************************************
//All code below this line should be functions only
#pragma code

//**************************************************************
//SUPPORTING FUNCTIONS START HERE
//**************************************************************
//FUNCTION NAME:    debouncePBx
//ARGUMENTS:        unsigned char input - input to debounce
//					unsigned char *count - pointer to count variables, on and off
//RETURNS:			_PBStates - see header file for definition          
//DESCRIPTION:      debounces a PushButton and returns the switch state
//					debouncePBx allows for separate on and off times
//**************************************************************
enum _PBStates debouncePBx( unsigned char input, unsigned int *count, 
							const rom unsigned int *dbnc_cnt_on,
							const rom unsigned int *dbnc_cnt_off,
							const rom unsigned int *hold_cnt)
{
	
 	enum _PBStates _PBState = RELEASED;
							
	if( input == 1 )					//if switch is pressed
	{
		*(count+1) = 0;					//clear off counter
		_PBState = DEBOUNCING;
		if( ++(*count) >= *hold_cnt )
		{
			_PBState = HELD;
			*count--;					//don't overflow
		}else if( *count >= *dbnc_cnt_on )
		{
			_PBState = PRESSED;
		}
	}else								//if switch is not pressed
	{
		*count = 0;						//clear on counter
		_PBState = DEBOUNCING;
		if( ++(*(count+1)) >= *dbnc_cnt_off )
		{
			_PBState = RELEASED;
			*(count+1)--;				//don't overflow
		}
	}
	return _PBState;
}

//**************************************************************
//FUNCTION NAME:    debouncePB
//ARGUMENTS:        unsigned char input - input to debounce
//					unsigned char *count - pointer to count variables, ON only
//RETURNS:			_PBStates - see header file for definition          
//DESCRIPTION:      debounces a PushButton and returns the switch state
//					debouncePB doesn't use a counter for off unlike debouncePBx
//**************************************************************
enum _PBStates debouncePB( unsigned char input, unsigned int *count, 
							const rom unsigned int *dbnc_cnt_on,
							const rom unsigned int *hold_cnt)
{
	
 	enum _PBStates _PBState = RELEASED;
							
	if( input == 1 )					//if switch is pressed
	{
		_PBState = DEBOUNCING;
		if( ++(*count) >= *hold_cnt )
		{
			_PBState = HELD;
			*count--;					//don't overflow
		}else if( *count >= *dbnc_cnt_on )
		{
			_PBState = PRESSED;
		}
	}else								//if switch is not pressed
	{
		*count = 0;						//clear on counter
	}
	return _PBState;
}