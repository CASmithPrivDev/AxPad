/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/           
// ****************************************************************** */
//
//
//  $Rev:: 3                                              $:  Revision of last commit
//  $Author:: reneleonrichard                             $:  Author of last commit
//  $Date:: 2011-07-27 17:54:46 -0400 (Wed, 27 Jul 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Source/usb_func.c $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************
#include <p18f2550.h>
#include <usb_func.h>

//**************************************************************
//place static constants here
//**************************************************************
#pragma romdata
  unsigned char DeviceDescriptorTable[0x12] = {0x12, 0x01,       //bLength, bDescriptorType
                                               0x00, 0x02,       //bcdUSB                         --0x0200 little endian
                                               0x00, 0x00,       //bDeviceClass, bDeviceSubClass
                                               0x00, 0x40,       //bDeviceProtocol, bMaxPacketSize
                                               0xD8, 0x04,       //idVendor                       --0x04D8
                                               0x98, 0xFE,       //id Product                     --0xFE98
                                               0x01, 0x00,       //bcdDevice                      --0x0001
                                               0x00, 0x01,       //iManufacturer (none), iProduct
                                               0x00, 0x01};      //iSerialNumber (none), bNumConfigurations

  unsigned char ConfigDescriptorTable[0x09] = {0x09, 0x02,       //bLength, bDescriptorType
                                               0x29, 0x00,       //wTotalLength                   --0x0029
                                               0x01, 0x01,       //bNumInterfaces, bConfigurationValue
                                               0x00, 0xC0,       //iConfiguration (none), bmAttributes
                                               0x32};            //bMaxPower (100mA)

  unsigned char ConfigDescriptorTableLong[0x29]=                 //equivalent to next 3 arrays concatenated
                                              {0x09, 0x02,
                                               0x29, 0x00,
                                               0x01, 0x01,
                                               0x00, 0xC0,
                                               0x32,
                                               0x09, 0x04,
                                               0x00, 0x00,
                                               0x02, 0x03,
                                               0x00, 0x00,
                                               0x00,
                                               0x09, 0x21,
                                               0x01, 0x01,
                                               0x00, 0x01,
                                               0x22, 
                                               0x21, 0x00,
                                               0x07, 0x05,
                                               0x81, 0x03,
                                               0x40, 0x00,
                                               0x0A,
                                               0x07, 0x05,
                                               0x01, 0x03,
                                               0x40, 0x00,
                                               0x0A};

  unsigned char InterfaceDescriptorTable[0x09] = 
                                              {0x09, 0x04,       //bLength, bDescriptorType
                                               0x00, 0x00,       //bInterfaceNumber, bAlternateSetting
                                               0x02, 0x03,       //bNumEndpoints, bInterfaceClass
                                               0x00, 0x00,       //bInterfaceSubClass, bInterfaceProtocol
                                               0x00};            //iInterface

  unsigned char ClassDescriptorTable[0x09] =  {0x09, 0x21,       //bLength, bDescriptorType
                                               0x01, 0x01,       //bcdHID
                                               0x00, 0x01,       //bCountryCode (none), bNumDescriptors
                                               0x22,             //bDescriptorType
                                               0x21, 0x00};      //wDescriptorLength                  --0x0021

  unsigned char InterruptInEndpointDescriptorTable[0x07] = 
                                              {0x07, 0x05,       //bLength, bDescriptorType
                                               0x81, 0x03,       //bEndpointAddress, bmAttributes
                                               0x40, 0x00,       //wMaxPacketSize                     --0x0040
                                               0x0A};            //bInterval (10 ms)

  unsigned char InterruptOUTEndpointDescriptorTable[0x07] = 
                                              {0x07, 0x05,       //bLength, bDescriptorType
                                               0x01, 0x03,       //bEndpointAddress, bmAttributes
                                               0x40, 0x00,       //wMaxPacketSize                     --0x0040
                                               0x0A};            //bInterval (10 ms)

#define ReportDescriptorByteLength 0x21
  unsigned char ReportDescriptorTable[0x21] = {0x06, 0xA0, 0xFF, //Usage page (vendor defined)
                                               0x09, 0x01,       //Usage ID (vendor defined)
                                               0xA1, 0x01,       //Collection (application)
  
                                               0x15, 0x00,       //Logical minimum (0)
                                               0x26, 0xFF, 0x00, //Logical maximum (255)
                                               0x75, 0x08,       //Report size (8 bits)
                             
                                               0x09, 0x03,       //Usage ID - vendor defined
                                               0x95, 0x40,       //Report Count (64 bytes)
                                               0x81, 0x02,       //Input (Data, Variable, Absolute)

                                               0x09, 0x04,       //Usage ID - vendor defined
                                               0x95, 0x40,       //Report Count (64 bytes)
                                               0x91, 0x02,       //Output (Data, Variable, Absolute)

                                               0x09, 0x05,       //Usage ID - vendor defined
                                               0x95, 0x02,       //Report Count (2 bytes)
                                               0xB1, 0x02,       //Feature (Data, Variable, Absolute)

                                               0xC0};            //End collection

  unsigned char LanguageDescriptorTable[0x04] =
                                              {0x04, 0x03,       //bLength, bDescriptorType
                                               0x09, 0x04};      //wLANGID[0]                         --0x0409

  unsigned char ProductDescriptorTable[0x2A] ={0x2A, 0x03,       //bLength, bDescriptorType
                                                'S', 0x00,       //bString
                                                'u', 0x00,
                                                'n', 0x00,
                                                ' ', 0x00,
                                                'B', 0x00,
                                                'a', 0x00,
                                                't', 0x00,
                                                't', 0x00,
                                                'e', 0x00,
                                                'r', 0x00,
                                                'y', 0x00,
                                                ' ', 0x00,
                                                'T', 0x00,
                                                'e', 0x00,
                                                's', 0x00,
                                                't', 0x00,
                                                ' ', 0x00,
                                                'J', 0x00,
                                                'i', 0x00,
                                                'g', 0x00};

//**************************************************************
//place unitialized variables here
//**************************************************************

#pragma udata access GP_USB_REGISTERS=0x0000
  
  near unsigned char BDnSTAT;
  near unsigned char BDnCNT;
  near unsigned int  BDnADDR;
  near unsigned char USBDATA[8];
  near unsigned char DEVICE_STATUS;
  near unsigned char IDLE_RATE;
  near unsigned char CURRENT_REQUEST;
  near unsigned char USB_ADDRESS;
  near unsigned char REQUEST_TYPE;
  near unsigned char EP_ACTIVITY;
  near unsigned char DEVICE_STATE;
  near unsigned char REPORT_TYPE;
  near unsigned char REQUEST_RECIPIENT;
  near unsigned char PID;
  near unsigned char LCOUNTER;
  near unsigned char SERIAL_COMMAND;
  near unsigned char USBRxCNT;
  near unsigned char USBTxCNT;

#pragma udata BUFFER_DESCRIPTOR=BUFFER_DESCRIPTOR_ADDR
  unsigned char BD0STAT;                 //0x0400
  unsigned char BD0CNT;                  //0x0401
  unsigned int  BD0ADDR;                 //0x0402
//  unsigned char BD0ADRH;                 //0x0403
  unsigned char BD1STAT;                 //0x0404
  unsigned char BD1CNT;                  //0x0405
  unsigned int  BD1ADDR;                 //0x0406
//  unsigned char BD1ADRH;                 //0x0407
  unsigned char BD2STAT;                 //0x0408
  unsigned char BD2CNT;                  //0x0409
  unsigned int  BD2ADDR;                 //0x040A
//  unsigned char BD2ADRH;                 //0x040B
  unsigned char BD3STAT;                 //0x040C
  unsigned char BD3CNT;                  //0x040D
  unsigned int  BD3ADDR;                 //0x040E
//  unsigned char BD3ADRH;                 //0x040F

#pragma udata USB_RAM_SPACE=USB_RAM
  unsigned char USB_EP0[64];
  unsigned char USB_EP1[64];
  unsigned char USB_EP2[64];
  unsigned char USB_EP3[64];

//**************************************************************
//place initialized variables here
//**************************************************************
#pragma idata

//**************************************************************
//place function prototypes here
//**************************************************************

//**************************************************************
//All code below this line should be functions only
#pragma code
//**************************************************************
//MAIN PROGRAM STARTS HERE/
//**************************************************************
//no main
//**************************************************************
//MAIN PROGRAM ENDS HERE
//**************************************************************

//**************************************************************
//SUPPORTING FUNCTIONS START HERE
//**************************************************************
//FUNCTION NAME:    
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************

void usb_isr(void){

  while(UIR){                 //stay here until all interrupts are serviced
    if(UIRbits.SOFIF == 1){   //START-OF-FRAME token received?
      UIRbits.SOFIF = 0;      //Acknowledge START-OF-FRAME interrupt
    }
    if(UIRbits.STALLIF == 1){ //STALL handshake sent by SIE?
      UEP0bits.EPSTALL = 0;   //Acknowledge endpoint stall condition
      UIRbits.STALLIF = 0;    //Acknowledge STALL interrupt
    }
    if(UIRbits.IDLEIF == 1){  //Idle state detected?
      UIRbits.IDLEIF = 0;     //Acknowledge idle state interrupt
      UCONbits.SUSPND = 1;    //Enter SIE suspend mode
    }
    if(UIRbits.TRNIF == 1){   //Transaction completed?
      usb_token();
    }
    if(UIRbits.ACTVIF == 1){  //Bus activity detected?
      UIRbits.ACTVIF = 0;     //Acknowledge bus activity interrupt
      UCONbits.SUSPND = 0;    //Exit SIE suspend mode
    }
    if(UIRbits.UERRIF == 1){  //SIE generated error detected?
      usb_error();            //SIE error handler
      UIRbits.UERRIF = 0;     //Acknowledge top level SIE error interrupt
    }
    if(UIRbits.URSTIF == 1){  //USB reset occurred?
      usb_reset();            //USB reset handler
    }
  }
  PIR2bits.USBIF = 0;         //Acknowledge top level USB interrupt
}

//**************************************************************
//FUNCTION NAME:  void sie_error(void)  
//ARGUMENTS:      none
//RETURNS:        none
//DESCRIPTION:    checks the UEIR register for errors flags
//**************************************************************

void usb_error(void){
  if(UEIRbits.BTSEF == 1){
    Nop();
  }
  if(UEIRbits.BTOEF == 1){
    Nop();
  }
  if(UEIRbits.DFN8EF == 1){
    Nop();
  }
  if(UEIRbits.CRC16EF == 1){
    Nop();
  }
  if(UEIRbits.CRC5EF == 1){
    Nop();
  }
  if(UEIRbits.PIDEF == 1){
    Nop();
  }
}

//**************************************************************
//FUNCTION NAME:  void usb_reset(void)  
//ARGUMENTS:      none
//RETURNS:        none
//DESCRIPTION:    
//**************************************************************
void usb_reset(void){
  
  near unsigned char *ptr;
  unsigned char i;

  UIRbits.TRNIF = 0;     //Clear TRNIF 4x to empty FIFO token buffer
  UIRbits.TRNIF = 0;
  UIRbits.TRNIF = 0;
  UIRbits.TRNIF = 0;
  
  ptr = &UEP0;           //Point to start of endpoint memory address
  for(i=0;i<16;i++){
    *(ptr++) = 0;        //Clear all 16 endpoints
  }
  
  BD0CNT = 64;           //EPO OUT = 64 byte packet length
  BD0ADDR = USB_RAM;     //Point BD0ADRH to address of EPO OUT RAM
  BD0STAT = 0b10001000;  //Enable data toggle synchronization, DATA0 packet, hand EP0 OUT control over to SIE
  
  BD1CNT = 64;           //EPO OUT = 64 byte packet length
  BD1ADDR = USB_RAM + 64;//Point BD0ADRH to address of EPO OUT RAM
  BD1STAT = 0b00001000;  //Enable data toggle synchronization, DATA0 packet, retain EP0 IN control

  UEP0 = 0b00010110;     //Enable UEP0, handshake enabled IN/OUT/SETUP transfers allowed

  DEVICE_STATE = DEFAULT_STATE;
  UADDR = 0;
  UIR = 0;
  UEIE = 0;
}


//**************************************************************
//FUNCTION NAME:  void usb_token(void)  
//ARGUMENTS:      none
//RETURNS:        none
//DESCRIPTION:    
//**************************************************************
void usb_token(void){

  unsigned char *ptr;
/*
  BDnSTAT = BD0STAT;                      //Transfer BDT registers to RAM
  BDnCNT = BD0CNT;            
  BDnADDR = BD0ADDR;
*/
  ptr = &BD0STAT + USTAT;                 //Use the USTAT register as the BDT offset (BD0STAT = 0x0400)
  BDnSTAT = *(ptr++);
  BDnCNT = *(ptr++);
  BDnADDR = (unsigned int)*(++ptr);       //retrieve high byte of address first
  BDnADDR <<= 8;
  BDnADDR &= 0xFF00;
  ptr--;
  BDnADDR |= *ptr;                        //retrieve low byte of address

  EP_ACTIVITY = USTAT & 0b00011000;       //Save the target endpoint
  PID = BDnSTAT & 0b00111100;             //Save the packet identifier
  
  UIRbits.TRNIF = 0;                      //Acknowledge TRNIF interrupt

  switch(PID){
    case TOKEN_SETUP:
      usb_token_setup();
      break;
    case TOKEN_IN:
      usb_in_token();
      break;
    case TOKEN_OUT:
      usb_out_token();
      break;
    default:
      usb_request_error();
      break;
  }
}


//**************************************************************
//FUNCTION NAME:  void usb_token_setup(void)  
//ARGUMENTS:      none
//RETURNS:        none
//DESCRIPTION:    
//**************************************************************
void usb_token_setup(void){

/*
  unsigned char BDnADDRL;
  unsigned char BDnADDRH;
  BDnADDRL = (unsigned char)BDnADDR;
  BDnADDRH = (unsigned char)BDnADDR>>8;

  _asm
    movff   BDnADDRH, FSR0H                     //Point FSR0 to the target endpoint   
    movff   BDnADDRL, FSR0L
    movff   POSTINC0, (USBDATA + bmRequestType) //Transfer the USB device request...
    movff   POSTINC0, (USBDATA + bRequest)      //fields to access RAM
    movff   POSTINC0, (USBDATA + wValue)
    movff   POSTINC0, (USBDATA + wValueHigh)
    movff   POSTINC0, (USBDATA + wIndex)
    movff   POSTINC0, (USBDATA + wIndexHigh)
    movff   POSTINC0, (USBDATA + wLength)
    movff   INDF0, (USBDATA + wLengthHigh)
  _endasm
*/
  unsigned char *ptr;
  unsigned char i;

  ptr = &USB_EP0[0] + (unsigned char)BDnADDR;   //&USB_EP0 = 0x0500 (USB_RAM)
  for(i=0;i<8;i++){                             //Transfer the USB device request fields to access RAM
    USBDATA[i] = *(ptr++);                     
  }

  BD0CNT = 64;                                  //Reset the EP0 byte count
  BD1STAT = 0b00001000;                         //Clear all bits except DTSEN, Return EP1 control to CPU

  if(USBDATA[bmRequestType] == 0b00100001){     //Data synchronization? (DATA0/DATA1)
    BD0STAT = 0b11001000;                       //DATA1 synchronization
  }else{
    BD0STAT = 0b10001000;                       //DATA0 synchronization
  }

  UCONbits.PKTDIS = 0;                          //Clear the packet disable bit
  CURRENT_REQUEST = NO_REQUEST;                 //Clear the current device request
  REQUEST_TYPE = 0b01100000 & USBDATA[bmRequestType]; //Extract request type
  REQUEST_RECIPIENT = 0b00011111 & USBDATA[bmRequestType]; //Extract request recipient
  
  switch(REQUEST_TYPE){
    case STANDARD_REQUEST:
      usb_standard_request();
      break;
    case CLASS_REQUEST:
      usb_class_request();
      break;
    default:
      usb_request_error();
      break;
  }
}

//**************************************************************
//FUNCTION NAME:  void usb_standard_request(void)  
//ARGUMENTS:      none
//RETURNS:        none
//DESCRIPTION:    
//**************************************************************
void usb_standard_request(void){
  
  unsigned char i;
  
  switch(USBDATA[bRequest]){
    case GET_STATUS:
      if(DEVICE_STATE == DEFAULT_STATE){          //Is the device in the default state?
        usb_request_error();                      //Yes, respond with a Request Error
      }else{
        switch(REQUEST_RECIPIENT){
          case RECIPIENT_DEVICE:
            USB_EP1[0] = 0x01;               
            USB_EP1[1] = 0x00;
            BD1CNT = 2;                           //Two byte packet
            BD1STAT = 0b11001000;                 //UOWN | DATA1 | DTSEN
            break;
          case RECIPIENT_INTERFACE:
            if(DEVICE_STATE != ADDRESS_STATE){    //Is the device in the addressed state?
              usb_request_error();                //Yes, respond with a request error
            }else
            if(USBDATA[wIndex] < NUM_INTERFACES){ //Does the specified interface exist
              USB_EP1[0] = 0x00;                  //respond with 0x0000
              USB_EP1[1] = 0x00;
              BD1CNT = 2;                         //Two byte packet
              BD1STAT = 0b11001000;               //UOWN | DATA1 | DTSEN
            }else{
              usb_request_error();
            }
            break;
          case RECIPIENT_ENDPOINT:
            USBDATA[wIndex] &= 0b00001111;        //Extract target endpoint
            switch(USBDATA[wIndex]){
              case 0:                             //Control endpoint status
                USB_EP1[0] = UEP0 & 0b00000001;   //Extract EP0 stall status
                USB_EP1[1] = 0x00;
                BD1CNT = 2;                       //Two byte packet
                BD1STAT = 0b11001000;             //UOWN | DATA1 | DTSEN
                break;
              case 1:                             //Interrupt endpoint status
                if(DEVICE_STATE != CONFIG_STATE){ //Is the device in the Configured state?
                  usb_request_error();            //No, respond with a request error
                }else{
                  USB_EP1[0] = UEP1 & 0b00000001; //Extract EP1 stall status
                  USB_EP1[1] = 0x00;
                  BD1CNT = 2;                     //Two byte packet
                  BD1STAT = 0b11001000;           //UOWN | DATA1 | DTSEN
                }
                break;
              default:
                usb_request_error();
                break;
            }     
            break;
          default:
            usb_request_error();
            break;
        }
        break;
      case CLEAR_FEATURE:
      case SET_FEATURE:
        switch(REQUEST_RECIPIENT){
          case RECIPIENT_DEVICE:                  //Device feature request?
            BD1CNT = 0;                           //Zero length packet
            BD1STAT = 0b11001000;                 //UOWN | DATA1 | DTSEN
            break;
          case RECIPIENT_ENDPOINT:                //Endpoint feature request?
            if(DEVICE_STATE == DEFAULT_STATE){    //Is the device in the Default state?
              usb_request_error();                //Yes, respond with a request error
            }else
            if(USBDATA[wValue] == ENDPOINT_HALT){
              USBDATA[wIndex] &= 0b00001111;      //Extract target endpoint
              switch(USBDATA[wIndex]){
                case 0:                             //Control endpoint feature request
                  switch(USBDATA[bRequest]){
                    case CLEAR_FEATURE:             //Clear control feature
                    case SET_FEATURE:               //Set control feature
                      BD1CNT = 0;                   //Zero length packet
                      BD1STAT = 0b11001000;         //UOWN | DATA1 | DTSEN
                      break;
                    default:
                      usb_request_error();
                      break;
                 }
                break;
                  case 1:                           //Interrupt endpoint feature request
                  if(DEVICE_STATE == ADDRESS_STATE){//Is the device in the Addressed state?
                    usb_request_error();
                  }else{
                    UEP1bits.EPSTALL ^= 1;          //Toggle bit
                    BD1CNT = 0;                     //Zero length packet
                    BD1STAT = 0b11001000;           //UOWN | DATA1 | DTSEN
                  }
                  break;
                default:
                  usb_request_error();
                  break;
              }
            }else{
              usb_request_error();
            }
            break;
          default:
            usb_request_error();                 
            break;
        }
        break;
      case SET_ADDRESS:
        if(USBDATA[wValue] > 0x7F){               //Valid USB addresses are 0x00 - 0x7F
          usb_request_error();                    //No valid address, respond with a request error
        }else{
          CURRENT_REQUEST = SET_ADDRESS;          //Processing a SET_ADDRESS request
          USB_ADDRESS = USBDATA[wValue];          //Save new address
          BD1CNT = 0;                             //Zero length packet
          BD1STAT = 0b11001000;                   //UOWN | DATA1 | DTSEN
        }
        break;
      case GET_DESCRIPTOR:
        CURRENT_REQUEST = GET_DESCRIPTOR;         //Processing a GET_DESCRIPTOR request
        switch(USBDATA[wValueHigh]){
          case DEVICE:                            //Device desciptor request
            BD1CNT = DeviceDescriptorTable[0];
            for(i=0;i<DeviceDescriptorTable[0];i++){
              USB_EP1[i] = DeviceDescriptorTable[i];
            }
            BD1STAT ^= 0b01000000;                //Toggle the DATA01 bit
            BD1STAT &= 0b01000000;                //Clear the PIDs bits
            BD1STAT |= 0b10001000;                //Set UOWN and DTS bits
            break;
          case CONFIGURATION:                     //Configuration descriptor request
            if(USBDATA[wLength] > ConfigDescriptorTable[0]){
              BD1CNT = 0x29;
              for(i=0;i<0x29;i++){
                USB_EP1[i] = ConfigDescriptorTableLong[i];
              }
            }else{
              BD1CNT = ConfigDescriptorTable[0];
              for(i=0;i<ConfigDescriptorTable[0];i++){
                USB_EP1[i] = ConfigDescriptorTable[i];
              }
            }
            BD1STAT ^= 0b01000000;                //Toggle the DATA01 bit
            BD1STAT &= 0b01000000;                //Clear the PIDs bits
            BD1STAT |= 0b10001000;                //Set UOWN and DTS bits
            break;
          case STRING:                            //String descriptor request
            switch(USBDATA[wValue]){
              case 0:                             //Language string request
                BD1CNT = LanguageDescriptorTable[0];
                for(i=0;i<LanguageDescriptorTable[0];i++){
                  USB_EP1[i] = LanguageDescriptorTable[i];
                }
                BD1STAT ^= 0b01000000;            //Toggle the DATA01 bit
                BD1STAT &= 0b01000000;            //Clear the PIDs bits
                BD1STAT |= 0b10001000;            //Set UOWN and DTS bits
                break;
              case 1:                             //Product string request
                BD1CNT = ProductDescriptorTable[0];
                for(i=0;i<ProductDescriptorTable[0];i++){
                  USB_EP1[i] = ProductDescriptorTable[i];
                }
                BD1STAT ^= 0b01000000;            //Toggle the DATA01 bit
                BD1STAT &= 0b01000000;            //Clear the PIDs bits
                BD1STAT |= 0b10001000;            //Set UOWN and DTS bits              
                break;
              default:
                usb_request_error();
                break;
            }
            break;
          case HID:                               //Class (HID) descriptor request
            BD1CNT = ClassDescriptorTable[0];
            for(i=0;i<ClassDescriptorTable[0];i++){
              USB_EP1[i] = ClassDescriptorTable[i];
            }
            BD1STAT ^= 0b01000000;                //Toggle the DATA01 bit
            BD1STAT &= 0b01000000;                //Clear the PIDs bits
            BD1STAT |= 0b10001000;                //Set UOWN and DTS bits
            break;
          case REPORT:                            //Report descriptor request
            BD1CNT = ReportDescriptorByteLength;  //HID report descriptor byte length
            for(i=0;i<ReportDescriptorByteLength;i++){
              USB_EP1[i] = ReportDescriptorTable[i];
            }
            BD1STAT ^= 0b01000000;                //Toggle the DATA01 bit
            BD1STAT &= 0b01000000;                //Clear the PIDs bits
            BD1STAT |= 0b10001000;                //Set UOWN and DTS bits
            break;
          default:
            usb_request_error();
        }
        break;
      case GET_CONFIGURATION:
        USB_EP1[0] = DEVICE_STATE;                //Send current configuration value
        BD1CNT = 1;                               //Single byte packet
        BD1STAT = 0b11001000;                     //UOWN | DATA1 | DTSEN
        break;
      case SET_CONFIGURATION:
        if(USBDATA[wValue] > NUM_CONFIGURATIONS){ //Does the configuration value match?
          usb_request_error();
        }else
        if(USBDATA[wValue] == 0){                 //Is wValue zero?
          DEVICE_STATE = ADDRESS_STATE;           //Yes, update the device state
          BD1CNT = 0;                             //Zero length packet
          BD1STAT = 0b11001000;                   //UOWN | DATA1 | DTSEN
        }else{                                    //No, configure the device
          BD2CNT = 0x40;                          //EP1 OUT = 64 byte length
          BD2ADDR = USB_RAM + 0x80;               //Point BD2ADDR to EP1 OUT RAM start address
          BD2STAT = 0b11001000;                   //Enable data toggle synchronization, DATA1 packet, hand EP1 OUT control over to SIE 
          BD3CNT = 0x40;                          //EP1 IN = 64 byte length
          BD3ADDR = USB_RAM + 0xC0;               //Point BD2ADDR to EP1 IN RAM start address
          BD3STAT = 0b01001000;                   //Enable data toggle synchronization, DATA1 packet, retain EP IN control
          UEP1 = 0b00011110;                      //Enable UEP1, handshake enabled IN/OUT transfers allowed

          DEVICE_STATE = CONFIG_STATE;            //Update the device state (CONFIGURED)
          BD1CNT = 0;                             //Zero length packet
          BD1STAT = 0b11001000;                   //UOWN | DATA1 | DTSEN
        }
        break;
      case GET_INTERFACE:
        if(DEVICE_STATE != CONFIG_STATE){         //Is the device in the configured state?
          usb_request_error();                    //No, respond with a request error
        }else{
          USB_EP1[0] = 0;                         //Return 0x00 for bAlternateSetting
          BD1CNT = 1;                             //One byte packet
          BD1STAT = 0b11001000;                   //UOWN | DATA1 | DTSEN
        }          
        break;
      case SET_INTERFACE:
        if(DEVICE_STATE != CONFIG_STATE){         //Is the device in the configured state?
          usb_request_error();                    //No, respond with a request error
        }else
        if(USBDATA[wIndex] < NUM_INTERFACES){     //Is an unimplemented interface selected
          usb_request_error();                    //Yes, respond with a request error
        }else{
          //TO DO: PROCESS SET_INTERFACE REQUEST
          BD1CNT = 0;                             //Zero length packet
          BD1STAT = 0b11001000;                   //UOWN | DATA1 | DTSEN
        }
        break;
      default:
        usb_request_error();
        break;
    }
  }
}

//**************************************************************
//FUNCTION NAME:  void usb_class_request(void)  
//ARGUMENTS:      none
//RETURNS:        none
//DESCRIPTION:    
//**************************************************************
void usb_class_request(void){

  switch(USBDATA[bRequest]){
    case GET_REPORT:
      switch(USBDATA[wValueHigh]){
        case INPUT:                               //Input report request
          //PROCESS GET INPUT REPORTS (DEVICE-TO-HOST) HERE
          BD1CNT = 0x40;                          //Reset EP0 IN byte count
          BD1STAT = 0b11001000;                   //UOWN | DATA1 | DTSEN
          break;
        case FEATURE:                             //Feature report request
          //PROCESS GET FEATURE REPORTS (DEVICE-TO-HOST) HERE
          BD1CNT = 0x02;                          //Two byte packet
          BD1STAT = 0b11001000;                   //UOWN | DATA1 | DTSEN
          break;
        default:
          usb_request_error();
          break;
      }
      break;
    case GET_IDLE:
      USB_EP1[0] = IDLE_RATE;                     //Copy current idle rate
      BD1CNT = 1;                                 //Single byte packet
      BD1STAT = 0b11001000;                       //UOWN | DATA1 | DTSEN 
      break;
    case SET_REPORT:
      switch(USBDATA[wValueHigh]){
        case OUTPUT:                              //Set output report request
          CURRENT_REQUEST = OUTPUT;               //Update the current request register
          break;
        case FEATURE:                             //Set feature report request
          CURRENT_REQUEST = FEATURE;              //Update the current request register
          break;
        default:
          usb_request_error();
          break;
      }
      break;
    case SET_IDLE:
      IDLE_RATE = USBDATA[wValueHigh];            //Update the idle rate
      BD1CNT = 0;                                 //Zero length packet
      BD1STAT = 0b11001000;                       //UOWN | DATA1 | DTSEN
      break;
    default:
      usb_request_error();
      break;
  }
}

//**************************************************************
//FUNCTION NAME:  void usb_in_token(void)  
//ARGUMENTS:      none
//RETURNS:        none
//DESCRIPTION:    
//**************************************************************
void usb_in_token(void){

  switch(EP_ACTIVITY){
    case EP0:                                     //EP0 data request
      if(CURRENT_REQUEST == SET_ADDRESS){         //Set address request?
        CURRENT_REQUEST = NO_REQUEST;             //Update the CURRENT_REQUEST register
        UADDR = USB_ADDRESS;                      //Update SIE with the device address
        if(UADDR == 0){                           //Is the new device address 0c00 (DEFAULT)?
          DEVICE_STATE = DEFAULT_STATE;           //Yes, update the devuce state (DEFAULT) 
        }else{
          DEVICE_STATE = ADDRESS_STATE;           //No, change device state to addressed
        }
      }else{
        CURRENT_REQUEST = NO_REQUEST;             //Update the CURRENT_REQUEST register
      }
      break;
    case EP1:                                     //EP1 data request, empty
      break;
    default:
      usb_request_error();
      break;   
  }
}

//**************************************************************
//FUNCTION NAME:  void usb_out_token(void)  
//ARGUMENTS:      none
//RETURNS:        none
//DESCRIPTION:    
//**************************************************************
void usb_out_token(void){
  
  switch(EP_ACTIVITY){
    case EP0:                                     //Control endpoint out token?
      switch(CURRENT_REQUEST){
        case OUTPUT:                              //SET_OUTPUT request?
          CURRENT_REQUEST = NO_REQUEST;           //Reset the CURRENT_REQUEST register
          BD0CNT = 0x40;                          //Reset the EP0 OUT byte count
          BD0STAT = 0b10001000;                   //UOWN | DTSEN
          BD1CNT = 0x00;                          //Zero length packet
          BD1STAT = 0b11001000;                   //UOWN | DATA1 | DTSEN
          break;
        case FEATURE:                             //SET_FEATURE request?
          CURRENT_REQUEST = NO_REQUEST;           //Reset the CURRENT_REQUEST register
          SERIAL_COMMAND = USB_EP0[0];            //Transfer serial command to holding register

          usb_set_feature_report(SERIAL_COMMAND); //Set feature report

          SERIAL_COMMAND = 0;
          BD0CNT = 0x40;                          //Reset the EP0 OUT byte count
          BD0STAT = 0b10001000;                   //UOWN | DTSEN
          BD1CNT = 0x00;                          //Zero Length Packet
          BD1STAT = 0b11001000;                   //UOWN | DATA1 | DTSEN
          break;
        default:
          usb_request_error();
          break;
      }
      break;
    case EP1:
        SERIAL_COMMAND = USB_EP2[0];              //Transfer serial command to holding register

        usb_interrupt_out_token(SERIAL_COMMAND);  //Interrupt out token

        BD2CNT = 0x40;                            //Reset the EP1 out
        BD2STAT ^= 0b01000000;                    //Toggle the DATA01 bit
        BD2STAT &= 0b01000000;                    //Clear the PIDs bits
        BD2STAT |= 0b10001000;                    //Set UOWN and DTS bits
      break;
    default:
      usb_request_error();
      break;
  }
}

//**************************************************************
//FUNCTION NAME:  void usb_request_error(void)  
//ARGUMENTS:      none
//RETURNS:        none
//DESCRIPTION:    
//**************************************************************
void usb_request_error(void){

  BD0STAT |= 0b10000100;                          //Set UOWN and BSTALL (EP0 OUT)
  BD1STAT |= 0b10000100;                          //Set UOWN and BSTALL (EP0 IN)
}

//**************************************************************
//FUNCTION NAME:  void usb_detect(void)  
//ARGUMENTS:      none
//RETURNS:        none
//DESCRIPTION:    This function detects the USB presence and resets the firmware
//**************************************************************
void usb_detect(void){
  
  INTCON3bits.INT1IF = 0;     //Acknowledge the INT1 interrupt
  INTCON3bits.INT1IE = 0;     //Disable the INT1 interrupt

  _asm reset _endasm          //execute a firmware reset upon USB connect or disconnect
}

//**************************************************************
//FUNCTION NAME:     void setup_usb(void)    
//ARGUMENTS:         none
//RETURNS:           none
//DESCRIPTION:       sets up the USB serial interface engine, USBSENSE on RB1
//**************************************************************
void setup_usb(void){

  UCFG = 0b00010100;          //Enable pull-up resistors, USB full-speed operation, ping-pong buffering disabled, SIE active
  UCON = 0;                   //Initialize the USB control register
  UEIE = 0;                   //Disable all SIE error interrupt sources
  UIE = 0;                    //Disable all USB interrupt sources
  PIE2bits.USBIE = 0;         //Disable (global) USB interrupts

  TRISBbits.TRISB1 = 1;       //RB1 = input (used to detect USB connection)
  INTCON3bits.INT1IP = 0;     //INT1 low priority interrupt
  INTCON3bits.INT1IF = 0;     //Initialize the INT1 interrupt flag

  if(USBSENSE){               //Is USB connected?
    INTCON2bits.INTEDG1 = 0;  //INT1 interrupt on falling edge
    INTCON3bits.INT1IE = 1;   //Enable the INT1 interrupt
    UIE = 0xFF;               //Enable all USB interrupt sources
    PIE2bits.USBIE = 1;       //Enable (global) USB interrupts
    UCONbits.USBEN = 1;       //Enable the SIE 
  }else{
    INTCON2bits.INTEDG1 = 1;  //INT1 interrupt on rising edge (detect connection)
    INTCON3bits.INT1IE = 1;   //Enable the INT1 interrupt
  }
}

//**************************************************************
//FUNCTION NAME:  void usb_set_feature_report(unsigned char)  
//ARGUMENTS:      cmd
//RETURNS:        none
//DESCRIPTION:    Place command decoding here for actions on USB data
//**************************************************************
void usb_set_feature_report(unsigned char cmd){

/*
  return data to PC in 64 byte chunks as follows
  while(BD3STAT & 0b10000000);                    //Do we own the interrupt space in RAM?
  //move data to USB_EP3[0..63];                  //move data to interrupt IN RAM space
  BD3CNT = 0x40;
  BD3STAT ^= 0b01000000;                          //Toggle the DATA01 bit
  BD3STAT &= 0b01000000;                          //Clear the PIDs bits
  BD3STAT |= 0b10001000;                          //Set UOWN and DTS bits
*/

  switch(cmd){
    

    default:
      break;
  }
}

//**************************************************************
//FUNCTION NAME:  void usb_interrupt_out_token(unsigned char)  
//ARGUMENTS:      cmd
//RETURNS:        none
//DESCRIPTION:    
//**************************************************************
void usb_interrupt_out_token(unsigned char cmd){

/*
  read IN data on USB_EP2[0..63];
  cmd = USB_EP2[0];
*/

  switch(cmd){
    

    default:
      break;
  }
}