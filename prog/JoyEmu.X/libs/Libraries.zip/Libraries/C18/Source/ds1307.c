
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 26                                             $:  Revision of last commit
//  $Author:: rrichard                                    $:  Author of last commit
//  $Date:: 2011-08-09 09:39:44 -0400 (Tue, 09 Aug 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Source/ds1307.c $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************

#include <p18cxxx.h>
#include <ds1307.h>
#include <i2c.h>

//**************************************************************
//static constants
//**************************************************************
#pragma romdata

const rom char ds1307_addr_write = 0b11010000;  //include RnW bit
const rom char ds1307_addr_read = 0b11010001;   //include RnW bit

//**************************************************************
//unitialized variables
//**************************************************************
#pragma udata

//**************************************************************
//place initialized variables here
//**************************************************************
#pragma idata

//**************************************************************
//internal function prototypes here
//**************************************************************
static unsigned short long ds1307DayToSeconds(unsigned char hours,
											  unsigned char minutes,
											  unsigned char seconds);

//**************************************************************
//All code below this line should be functions only
#pragma code

//**************************************************************
//SUPPORTING FUNCTIONS START HERE
//**************************************************************
//FUNCTION NAME:    ds1307ReadTime
//ARGUMENTS:        struct _ds1307Time *timeBCD - pointer to hold time data
//RETURNS:          -1 if device not ack
//					0  if success
//DESCRIPTION:      reads out all of the time data from the ds1307
//**************************************************************
char ds1307ReadTime(struct _ds1307TimeBCD *timeBCD)
{
	StartI2C();
	WriteI2C(ds1307_addr_write);

	/* return -1 if device did not acknowledge */
	if(SSPCON2bits.ACKSTAT == 1)
	{
		StopI2C();
		return -1;
	}	
	
	WriteI2C(DS1307_SECONDS_REGISTER);
	RestartI2C();
	WriteI2C(ds1307_addr_read);
	
	(timeBCD)->seconds = ReadI2C();
	AckI2C();
	(timeBCD)->minutes = ReadI2C();
	AckI2C();
	(timeBCD)->hours = ReadI2C();
	AckI2C();
	(timeBCD)->day = ReadI2C();
	AckI2C();
	(timeBCD)->date = ReadI2C();
	AckI2C();
	(timeBCD)->month = ReadI2C();
	AckI2C();
	(timeBCD)->year = ReadI2C();
	AckI2C();
	(timeBCD)->control = ReadI2C();
	NotAckI2C();
	StopI2C();

	return 0;
}

//**************************************************************
//FUNCTION NAME:    ds1307ReadTime
//ARGUMENTS:        struct _ds1307Time *timeBCD - pointer to hold time data
//RETURNS:          -1 if device not ack
//					0  if success
//DESCRIPTION:      sets all of the time data in the ds1307,
//					also sets the CH bit to 0 in order to start the oscillator
//**************************************************************
char ds1307SetTime(struct _ds1307TimeBCD *timeBCD)
{
	StartI2C();
	WriteI2C(ds1307_addr_write);

	/* return -1 if device did not acknowledge */
	if(SSPCON2bits.ACKSTAT == 1)
	{
		StopI2C();
		return -1;
	}	
	
	WriteI2C(DS1307_SECONDS_REGISTER);
	WriteI2C( (timeBCD)->seconds & 0x7F );  //ensure that CH = 0
	WriteI2C( (timeBCD)->minutes );
	WriteI2C( (timeBCD)->hours );
	WriteI2C( (timeBCD)->day );
	WriteI2C( (timeBCD)->date );
	WriteI2C( (timeBCD)->month );
	WriteI2C( (timeBCD)->year );
	StopI2C();

	return 0;
}

//**************************************************************
//FUNCTION NAME:    ds1307SetSQWE
//ARGUMENTS:        enum _DS1307FREQ frequency - 	0 =     1Hz
//													1 =  4096Hz
//													2 =  8192Hz
//													3 = 32768HZ
//					unsigned char enable		
//RETURNS:          -1 if device not ack
//					0  if success
//DESCRIPTION:      sets the SQWE bit and frequency accordingly
//**************************************************************
char ds1307SetSQWE(enum _DS1307FREQ frequency, char enable)
{
	/* safety on enable bit */
	enable &= DS1307_SQWE_ENABLE;

	StartI2C();
	WriteI2C(ds1307_addr_write);

	/* return -1 if device did not acknowledge */
	if(SSPCON2bits.ACKSTAT == 1)
	{
		StopI2C();
		return -1;
	}

	WriteI2C(DS1307_CONTROL_REGISTER);
	WriteI2C( frequency + enable );
	StopI2C();

	return 0;
}

//**************************************************************
//FUNCTION NAME:    ds1307ConvertTime
//ARGUMENTS:        		
//RETURNS:          
//DESCRIPTION:		
//**************************************************************
void ds1307ConvertTime(struct _ds1307TimeBCD *timeBCD, struct _ds1307Time *time)
{
	struct _ds1307TimeBCD timeBCDWork;

	timeBCDWork = *timeBCD;
	// ensure CH bit does not corrupt time conversion
	timeBCDWork.seconds &= 0x7F;	

	// convert seconds
	(time)->seconds = 0;
	while( timeBCDWork.seconds >= 0x10 )
	{
		(time)->seconds += 10;
		timeBCDWork.seconds -= 0x10;
	}
	while( timeBCDWork.seconds >= 1 )
	{
		(time)->seconds++;
		timeBCDWork.seconds--;
	}

	// convert minutes
	(time)->minutes = 0;
	while( timeBCDWork.minutes >= 0x10 )
	{
		(time)->minutes += 10;
		timeBCDWork.minutes -= 0x10;
	}
	while( timeBCDWork.minutes >= 1 )
	{
		(time)->minutes++;
		timeBCDWork.minutes--;
	}

	// convert hours, check if 12 hour clock is used
	(time)->hours = 0;
	if(timeBCDWork.hours & 0b01000000)  //bit6 = '1' = 12 hour clock
	{
		// remove 12/24 hour select bit for conversion
		timeBCDWork.hours &= 0b10111111;
		// set bit7 to '1' if time is in PM
		if(timeBCDWork.hours & 0b00100000)
		{
			(time)->hours |= 0b10000000;
		}
	}
	while( timeBCDWork.hours >= 0x10 )
	{
		(time)->hours += 10;
		timeBCDWork.hours -= 0x10;
	}
	while( timeBCDWork.hours >= 1 )
	{
		(time)->hours++;
		timeBCDWork.hours--;
	}

	// no conversion on day is necessary
	(time)->day = timeBCDWork.day;

	// convert date
	(time)->date = 0;
	while( timeBCDWork.date >= 0x10 )
	{
		(time)->date += 10;
		timeBCDWork.date -= 0x10;
	}
	while( timeBCDWork.date >= 1 )
	{
		(time)->date++;
		timeBCDWork.date--;
	}	

	// convert month
	(time)->month = 0;
	while( timeBCDWork.month >= 0x10 )
	{
		(time)->month += 10;
		timeBCDWork.month -= 0x10;
	}
	while( timeBCDWork.month >= 1 )
	{
		(time)->month++;
		timeBCDWork.month--;
	}

	// convert year
	(time)->year = 0;
	while( timeBCDWork.year >= 0x10 )
	{
		(time)->year += 10;
		timeBCDWork.year -= 0x10;
	}
	while( timeBCDWork.year >= 1 )
	{
		(time)->year++;
		timeBCDWork.year--;
	}

}

//**************************************************************
//FUNCTION NAME:    ds1307CompareDailyAlarm
//ARGUMENTS:        		
//RETURNS:          
//DESCRIPTION:		
//**************************************************************
char ds1307CompareDailyAlarm(struct _ds1307Time *time, const rom struct _ds1307DailyAlarm *alarm)
{
	if ( (time)->seconds == (alarm)->seconds )
	{
		if ( (time)->minutes == (alarm)->minutes )
		{
			if ( (time)->hours == (alarm)->hours )
			{
				return 1;
			}
		}
	}
	return 0;
}

//**************************************************************
//FUNCTION NAME:    ds1307IsTimeBetween
//ARGUMENTS:        		
//RETURNS:          
//DESCRIPTION:		
//**************************************************************
char ds1307IsTimeBetween(struct _ds1307Time *time, const rom struct _ds1307DailyAlarm *early,
								const rom struct _ds1307DailyAlarm *late)
{
	unsigned short long  time_s, early_s, late_s;

	/* convert everything to seconds to make comparison easier */
	time_s = ds1307DayToSeconds( (time)->hours, (time)->minutes, (time)->seconds );
	early_s = ds1307DayToSeconds( (early)->hours, (early)->minutes, (early)->seconds );
	late_s = ds1307DayToSeconds( (late)->hours, (late)->minutes, (late)->seconds );	

	if( (time_s >= early_s) && (time_s <= late_s) )
	{
		return 1;
	}
	return 0;
}

//**************************************************************
//FUNCTION NAME:    ds1307DayToSeconds
//ARGUMENTS:        		
//RETURNS:          
//DESCRIPTION:		
//**************************************************************
static unsigned short long ds1307DayToSeconds(unsigned char hours,
											  unsigned char minutes,
											  unsigned char seconds)
{
	unsigned short long var = 0;

	while( seconds >= 1 )
	{
		var++;
		seconds--;
	}
	while( minutes >= 1 )
	{
		var += 60;
		minutes--;
	}
	while( hours >= 1 )
	{
		var += 3600;
		hours--;
	}
	return var;
}