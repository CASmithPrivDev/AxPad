
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 83                                             $:  Revision of last commit
//  $Author:: rrichard                                    $:  Author of last commit
//  $Date:: 2011-12-16 15:17:00 -0500 (Fri, 16 Dec 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Headers/i2c_eeprom_4x_24xx102x.h $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************

#ifndef I2C_EEPROM_4MBIT_H
#define	I2C_EEPROM_4MBIT_H

#define BLOCK0_ID		0b10100000
#define BLOCK1_ID		0b10101000
#define BLOCK2_ID		0b10100010
#define BLOCK3_ID		0b10101010
#define BLOCK4_ID		0b10100100
#define BLOCK5_ID		0b10101100
#define BLOCK6_ID		0b10100110
#define BLOCK7_ID		0b10101110

#define BLOCK0_RANGE	0x00FFFF
#define BLOCK1_RANGE	0x01FFFF
#define BLOCK2_RANGE	0x02FFFF
#define BLOCK3_RANGE	0x03FFFF
#define BLOCK4_RANGE	0x04FFFF
#define BLOCK5_RANGE	0x05FFFF
#define BLOCK6_RANGE	0x06FFFF
#define BLOCK7_RANGE	0x07FFFF

#define PAGE_BOUNDARY	0xFF80
#define PAGE_SIZE		128

/* data defined for patch */
union _patchData
{
	char bytes[128];
	struct
	{
		char name[10];
		struct
		{
			unsigned char channel;
			unsigned char value;
		}pc[16];
		struct
		{
			unsigned char channel;
			unsigned char ctrl;
			unsigned char value;
		}cc[8];
		struct _expPedalData expPedal[8];
		unsigned char iasOn[4];
		struct
		{
			char string[15];
			unsigned char size;
		}custom;
		union _expGlobalCfg
		{
			unsigned char expGlobalByte;
			struct
			{
				unsigned globalID	:3;
				unsigned 			:4;
				unsigned useGlobal	:1;
			}cfgBits;
		}expGlobalCfg;
	}params;
};

/* data defined for expression pedals */
union _expPedalData
{
	char bytes[6];
	struct
	{
		unsigned char channel;
		unsigned char ctrl;
		unsigned char lowValue;
		unsigned char hiValue;
		unsigned char defValue;
		union _expCfg
		{
			unsigned char cfgByte;
			struct
			{
				unsigned pedal		:2;
				unsigned txOnLoad	:1;	
				unsigned smooth		:1;
				unsigned 			:4;
			}cfgBits;
		}cfg;
	}params;
};

/* data defined for global expression pedals */
union _globalExp
{
	char bytes[64];
	union _expPedalData expPedal[8];
};

/* data defined for instant access switches */
union _iasData
{
	char bytes[64];
	struct
	{
		struct
		{
			unsigned char channel;
			unsigned char ctrl;
			unsigned char valueOn;
			unsigned char valueOff;
		}cc[8];	
		unsigned char iasExclusivity[4];
		struct
		{
			char string[15];
			unsigned char size;
		}custom;
		union
		{
			unsigned char cfgByte;
			struct
			{
				unsigned startOn	:1;
				unsigned latching	:1;
				unsigned 			:6;
			}cfgBits;
		}cfg;
	}params;
};

//**************************************************************
//external function prototypes
//**************************************************************
char memoryWriteByte(unsigned short long address, char *data);
char memoryWritePage(unsigned short long address, char *data);
char memoryReadByte(unsigned short long address, char *data);
char memoryReadPage(unsigned short long address, char *data);
char memoryIsWriteDone(unsigned short long address);

#endif /* I2C_EEPROM_4MBIT_H */