
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 3                                              $:  Revision of last commit
//  $Author:: reneleonrichard                             $:  Author of last commit
//  $Date:: 2011-07-27 17:54:46 -0400 (Wed, 27 Jul 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Headers/i2cx_eeprom.h $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************

#ifndef  I2CX_EEPROM_H
#define  I2CX_EEPROM_H

#include <GenericTypeDefs.h>

/* eeprom defines */
#define EEPROM_NUMBER			8

/* eeprom detected */
/* eeprom status */
#define EEPROM_CLOSED			0
#define EEPROM_OPEN				1
#define EEPROM_ERROR			2
#define EEPROM_NOT_ACK			4
#define EEPROM_FOUND			8
#define EEPROM_NOT_FOUND		16
#define EEPROM_MAXED			32		//returned when eeprom ID is greater than EEPROM_NUMBER
#define EEPROM_SUCCESS			128

/* values return by WriteI2C() */
#define ACK						0
#define NACK					-2
#define WCOLLISION				-1

/* i2c read and write bits */
#define I2C_READ				1
#define I2C_WRITE				0
#define I2C_NONE				128

/* i2c bus identifiers */
#define I2C_1					1
#define I2C_2					2

//**************************************************************
//external function prototypes
//**************************************************************

#if defined ( __18F66J50_H )
BYTE i2c_eeprom_open(BYTE id, BYTE bus, BYTE control, BYTE page_size);
#elif defined ( __18F4620_H ) || defined ( __18F6720_H )
BYTE i2c_eeprom_open(BYTE id, BYTE control, BYTE page_size);
#endif
BYTE i2c_eeprom_close(BYTE id);
void i2c_eeprom_init_driver(void);
BYTE i2c_eeprom_read_byte(BYTE id, WORD address, BYTE *data);
BYTE i2c_eeprom_read_length(BYTE id, WORD address, BYTE *data, BYTE length);
BYTE i2c_eeprom_read_page(BYTE id, WORD address, BYTE *data);
BYTE i2c_eeprom_write_byte(BYTE id, WORD address, BYTE *data);
BYTE i2c_eeprom_write_page(BYTE id, WORD address, BYTE *data);
BYTE i2c_eeprom_write_done(BYTE id);


#endif /* I2CX_EEPROM_H */