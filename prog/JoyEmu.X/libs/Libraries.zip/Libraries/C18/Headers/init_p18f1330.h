
//  $Rev:: 14                                             $:  Revision of last commit
//  $Author:: reneleonrichard                             $:  Author of last commit
//  $Date:: 2011-08-02 14:31:02 -0400 (Tue, 02 Aug 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Headers/init_p18f1330.h $
//
//*************************************************************
//defines, includes, enums here
//**************************************************************

#include <GenericTypeDefs.h>

#ifndef  INIT_P18F1330_H
#define  INIT_P18F1330_H

//**************************************************************
//external function prototypes
//**************************************************************
void init_device(void (*_initFuncPtr)(void));

#endif /* HEADER_H */