
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 23                                             $:  Revision of last commit
//  $Author:: rrichard                                    $:  Author of last commit
//  $Date:: 2011-08-05 13:06:57 -0400 (Fri, 05 Aug 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Headers/ds1307.h $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************

#ifndef DS1307_H
#define	DS1307_H


/* register addresses inside the DS1307 */
#define DS1307_SECONDS_REGISTER		0x00
#define DS1307_CONTROL_REGISTER		0x07
#define DS1307_SQWE_ENABLE			0x10
#define DS1307_SQWE_DISABLE			0x00

/* struct and enums to store time data */
enum _DAYS{Sunday = 1, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday};
enum _MONTHS{January = 1, February, March, April, May, June, July, August, September, October, November, December}; 
enum _DS1307FREQ{ _1Hz = 0, _4092Hz, _8192Hz, _32768Hz};

struct _ds1307TimeBCD
{
	unsigned char 	seconds;
	unsigned char 	minutes;
	unsigned char 	hours;
	enum _DAYS		day;
	unsigned char 	date;
	enum _MONTHS	month;
	unsigned char 	year;
	unsigned char 	control;
};

struct _ds1307Time
{
	unsigned char 	seconds;
	unsigned char 	minutes;
	unsigned char 	hours;
	enum _DAYS		day;
	unsigned char 	date;
	enum _MONTHS	month;
	unsigned char 	year;
};

struct _ds1307DailyAlarm
{
	unsigned char 	hours;
	unsigned char 	minutes;
	unsigned char 	seconds;
};

//**************************************************************
//external function prototypes
//**************************************************************

char ds1307ReadTime(struct _ds1307TimeBCD *time);
char ds1307SetTime(struct _ds1307TimeBCD *time);
char ds1307SetSQWE(enum _DS1307FREQ frequency, char enable);
void ds1307ConvertTime(struct _ds1307TimeBCD *timeBCD, struct _ds1307Time *time);

char ds1307CompareDailyAlarm(struct _ds1307Time *time, const rom struct _ds1307DailyAlarm *alarm);
char ds1307IsTimeBetween(struct _ds1307Time *time, const rom struct _ds1307DailyAlarm *early,
								const rom struct _ds1307DailyAlarm *late);

#endif /* DS1307_H */