/*
 * Copyright (c) 2004-2005, Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */
//*************************************************************
//
//  $Rev:: 34                                             $:  Revision of last commit
//  $Author:: rrichard                                    $:  Author of last commit
//  $Date:: 2011-09-15 13:08:34 -0400 (Thu, 15 Sep 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Headers/pt_rene.h $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************
#ifndef __PT_RENE_H__
#define __PT_RENE_H__

#include "lc-switch.h"

struct pt 
{
	lc_t lc;
	unsigned int ticks;				//use this variable along with timer interrupts to generate timed yields
	char run;					
	union{
		struct{
			unsigned sleep		:1;
			unsigned yield		:1;
			unsigned			:6;
		}bits;
		char byte;
	}flags;
};


#define PT_RUN_ONCE		1
#define PT_RUN_ALWAYS	2

#define PT_SLEEPING		1
#define PT_YIELDING 	2
#define PT_RUNNING		4
#define PT_EXITED  		8			//exited and yielded must always be the largest values
#define PT_ENDED   		16

//**************************************************************
//MACRO NAME:	    PT_THREAD  
//ARGUMENTS:        name_args
//RETURNS:          
//DESCRIPTION:      declare a function implementing a thread
//					static PT_THREAD(foo(struct pt *pt));
//**************************************************************
#define PT_THREAD(name_args) char name_args

//**************************************************************
//MACRO NAME:	    PT_BEGIN  
//ARGUMENTS:        pt
//RETURNS:          current state of thread (when exiting)
//DESCRIPTION:      declare the start of the thread within 
//					the C function, all code before PT_BEGIN will
//					executed everytime the function is called. MUST
//					be used in conjunction with a PT_END macro.
//**************************************************************
#define PT_BEGIN(pt)										\
	{														\
		if( (pt)->run == 0 )								\
		{													\
			LC_INIT((pt)->lc);								\
			return PT_ENDED;								\
		}else if ( (pt)->flags.bits.sleep == 1 )			\
		{													\
			return PT_SLEEPING;								\
		}													\
		LC_RESUME((pt)->lc);									
							
//**************************************************************
//MACRO NAME:	    PT_END 
//ARGUMENTS:        pt
//RETURNS:          current state of thread (when exiting)
//DESCRIPTION:      declare the end of the protothread within the
//					C function. MUST be used in conjunction with 
//					a PT_BEGIN macro.
//**************************************************************
#define PT_END(pt) 							\
		LC_END((pt)->lc); 					\
		if( (pt)->run == PT_RUN_ALWAYS )	\
		{									\
			LC_INIT((pt)->lc);				\
			return PT_RUNNING;				\
		}else{								\
			(pt)->run = 0;					\
			LC_INIT((pt)->lc);				\
			return PT_ENDED;				\
		}									\
	}

#define PT_BEGIN_CONTEXT typedef struct ctx{ char init_ctx
	
#define PT_END_CONTEXT(ctx_name) } ctx_name; ctx_name *pt_ctx 

//**************************************************************
//MACRO NAME:	    PT_YIELD
//ARGUMENTS:        pt
//RETURNS:          current state of thread (when exiting)
//DESCRIPTION:      yield processor to other threads
//**************************************************************
#define PT_YIELD(pt)						\
do{											\
	(pt)->flags.bits.yield = 1;				\
	LC_SET((pt)->lc);						\
	if( (pt)->flags.bits.yield == 1 )		\
	{										\
		(pt)->flags.bits.yield = 0;			\
		return PT_YIELDING;					\
	}										\
}while(0)

//**************************************************************
//MACRO NAME:	    PT_YIELD_UNTIL  
//ARGUMENTS:        pt
//					condition
//RETURNS:          current state of thread (when exiting)
//DESCRIPTION:      yield processor to other threads until condition
//					evalutes to non-zero, and, sleep if required
//**************************************************************
#define PT_YIELD_UNTIL(pt, condition)		\
do{											\
	(pt)->flags.bits.yield = 1;				\
	LC_SET((pt)->lc);						\										\
	if( !condition )						\
	{										\
		return PT_YIELDING;					\
	}										\
	(pt)->flags.bits.yield = 0;				\
}while(0)

//**************************************************************
//MACRO NAME:	    PT_YIELD_WHILE  
//ARGUMENTS:        pt
//					condition
//RETURNS:          current state of thread (when exiting)
//DESCRIPTION:      yield processor to other threads while condition
//					evalutes to non-zero, and, sleep if required
//**************************************************************
#define PT_YIELD_WHILE(pt, cond)  PT_YIELD_UNTIL((pt), !(cond))

//**************************************************************
//MACRO NAME:	    PT_YIELD_TICKS
//ARGUMENTS:        amount - 16bit unsigned amount of ticks to yield
//RETURNS:          
//DESCRIPTION:      yield processor to other threads for an
//					defined amount of ticks. ticks variable is 
//					external and must be setup in order for this
//					macro to function... i.e.
/*
//ticks, FOSC = 32MHz, TMR0 incs every 8MHz - ticks at 1ms
#define TMR0_TICK_VALUE			8000
#pragma romdata
WORD tmr0_count_reset = (0xFFFF - TMR0_TICK_VALUE);
#pragma udata
//tick every 1ms
static unsigned int ticks;
#pragma code
//init timer0 for ticks
	INTCON2bits.TMR0IP = 1;
	OpenTimer0(TIMER_INT_ON & T0_16BIT & T0_SOURCE_INT & T0_PS_1_1);
	INTCONbits.TMR0IE = 1;
#pragma code high_vector=0x08
void interrupt_at_high_vector(void)
{
_asm GOTO high_isr _endasm
}
#pragma code //return to the default code section
#pragma interrupt high_isr
void high_isr (void)
{
	INTCONbits.GIEH = 0;

	if( (INTCONbits.TMR0IE == 1) && (INTCONbits.TMR0IF == 1) ){
		INTCONbits.TMR0IF = 0;
		WriteTimer0(tmr0_count_reset);
		ticks++;
	}

	RCONbits.IPEN = 1;        //enable priority levels on interrupts
	INTCONbits.GIEH = 1;      //enable high priority interrupts
}
*/
//**************************************************************
extern unsigned int ticks;
#define PT_YIELD_TICKS(amount)		\
do{									\
	(pt)->ticks = ticks;			\
	PT_YIELD_WHILE(pt, (ticks - (pt)->ticks < amount) );		\
}while(0)

//**************************************************************
//MACRO NAME:	    PT_YIELD_WHILE_THREAD  
//ARGUMENTS:        pt
//					thread
//RETURNS:          
//DESCRIPTION:      yield processor to the specified thread until
//					it ends or exits, thread must be scheduled first
//**************************************************************
#define PT_YIELD_WHILE_THREAD(pt, thread) PT_YIELD_WHILE(pt, PT_RUN_THREAD(thread))

//**************************************************************
//MACRO NAME:	    PT_SPAWN
//ARGUMENTS:        pt
//					child_pt
//					thread
//RETURNS:          
//DESCRIPTION:      initialize child and yield processor to other 
//					threads while called thread runs until it ends 
//					or exits.
//**************************************************************
#define PT_SPAWN(pt, child_pt, thread)			\
do{												\
	PT_SCHEDULE_THREAD(child_pt, 1);			\
    PT_YIELD_WHILE_THREAD(pt, thread);			\
}while(0)	

//**************************************************************
//MACRO NAME:	    PT_RESTART  
//ARGUMENTS:        pt
//RETURNS:          
//DESCRIPTION:      restart execution of the current thread
//**************************************************************
#define PT_RESTART(pt)				\
do{									\
    LC_INIT(pt);					\
    return PT_EXITED;				\
}while(0)
//**************************************************************
//MACRO NAME:	    PT_EXIT  
//ARGUMENTS:        pt
//RETURNS:          
//DESCRIPTION:      stop and exit the current thread
//**************************************************************
#define PT_EXIT(pt)				\
do{								\
    LC_INIT(pt);				\
    return PT_EXITED;			\
}while(0)


//**************************************************************
//MACRO NAME:	    PT_RUN_THREAD  
//ARGUMENTS:        f
//RETURNS:          returns 1 if thread is still running
//					returns 0 if thread has completed
//DESCRIPTION:      run the specified thread 
//**************************************************************
#define PT_RUN_THREAD(f) ((f) < PT_EXITED)

//**************************************************************
//MACRO NAME:	    PT_SLEEP
//ARGUMENTS:        pt
//RETURNS:          
//DESCRIPTION:      put the current thread to sleep, must be
//					awakened by an external thread
//**************************************************************
#define PT_SLEEP(pt)									\
do{														\
    (pt)->flags.bits.sleep = 1; 						\
    LC_SET((pt)->lc);									\
	if((pt)->flags.bits.sleep)							\
	{													\
		return PT_SLEEPING;								\
	}													\
}while(0)

//**************************************************************
//MACRO NAME:	    PT_SLEEP_EXT
//ARGUMENTS:        pt
//RETURNS:          
//DESCRIPTION:      put another thread to sleep externally
//**************************************************************
#define PT_SLEEP_EXT(pt) ((pt)->flags.bits.sleep = 1)

//**************************************************************
//MACRO NAME:	    PT_WAKE
//ARGUMENTS:        pt
//RETURNS:          
//DESCRIPTION:      awaken a sleeping thread
//**************************************************************
#define PT_WAKE(pt) ((pt)->flags.bits.sleep = 0)

//**************************************************************
//MACRO NAME:	    PT_KILL
//ARGUMENTS:        pt
//RETURNS:          
//DESCRIPTION:      kill a thread, thread can be restarted with 
//					PT_SCHEDULE_THREAD, or unkilled but not
//					scheduled using PT_INIT
//**************************************************************
#define PT_KILL(pt) (PT_INIT(pt))

//**************************************************************
//MACRO NAME:	    PT_ISSLEEPING
//ARGUMENTS:        pt
//RETURNS:          1 if thread is sleeping
//					0 if thread is not sleeping
//DESCRIPTION:      checks if a thread is sleeping
//**************************************************************
#define PT_ISSLEEPING(pt) ((pt)->flags.bits.sleep)

//**************************************************************
//MACRO NAME:	    PT_ISYIELDING
//ARGUMENTS:        pt
//RETURNS:          1 if thread is yielding
//					0 if thread is not yielding
//DESCRIPTION:      checks if a thread is yielding
//**************************************************************
#define PT_ISYIELDING(pt) ((pt)->flags.bits.yield)

//**************************************************************
//MACRO NAME:	    PT_ISRUNNING
//ARGUMENTS:        pt
//RETURNS:          1 if thread is in always running mode
//					0 if thread is not in always running mode
//DESCRIPTION:      checks if a thread is in always running mode
//**************************************************************
#define PT_ISRUNNING(pt)   ((pt)->flags.bits.run)

//**************************************************************
//External function prototypes
//**************************************************************
void PT_INIT(struct pt *pt);
void PT_SCHEDULE_THREAD(struct pt *pt, char runcmd);
  
#endif /* __PT_RENE_H__ */

/** @} */
