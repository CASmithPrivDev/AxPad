
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 3                                              $:  Revision of last commit
//  $Author:: reneleonrichard                             $:  Author of last commit
//  $Date:: 2011-07-27 17:54:46 -0400 (Wed, 27 Jul 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Headers/usb_func.h $
//
//*************************************************************
//defines, includes, enums here
//**************************************************************

#ifndef USB_FUNC_H
#define USB_FUNC_H

#define BUFFER_DESCRIPTOR_ADDR 0x0400
#define USB_RAM 0x0500
#define USBSENSE PORTBbits.RB1

//****************************************************************************************
// DEVICE STATES
//****************************************************************************************
#define	ADDRESS_STATE           0x00
#define	CONFIG_STATE            0x01
#define	DEFAULT_STATE           0x02

//****************************************************************************************
// ENDPOINT STATES
//****************************************************************************************
#define EP0                     0x00 << 3
#define EP1                     0x01 << 3
#define EP2                     0x02 << 3
#define	EP_IDLE_STATE           0x00
#define	EP_SETUP_STATE          0x01
#define	EP_DISABLED_STATE       0xFF

#define	ENDPT_DISABLED          0x00
#define ENDPT_IN_ONLY           0x12
#define ENDPT_OUT_ONLY          0x14
#define ENDPT_CONTROL           0x16	
#define ENDPT_NON_CONTROL       0x1E

//****************************************************************************************
// TOKEN TYPES
//****************************************************************************************
#define TOKEN_OUT               0x01 << 2
#define TOKEN_ACK               0x02 << 2
#define TOKEN_IN                0x09 << 2
#define TOKEN_SETUP             0x0D << 2

//****************************************************************************************
// USB REQUEST TYPES
//****************************************************************************************
#define STANDARD_REQUEST        0x00 << 5
#define CLASS_REQUEST           0x01 << 5

//****************************************************************************************
// STANDARD USB REQUESTS
//****************************************************************************************
#define NO_REQUEST              0xFF
#define GET_STATUS              0x00
#define CLEAR_FEATURE           0x01
#define SET_FEATURE             0x03
#define SET_ADDRESS             0x05
#define GET_DESCRIPTOR          0x06
#define SET_DESCRIPTOR          0x07
#define GET_CONFIGURATION       0x08
#define SET_CONFIGURATION       0x09
#define GET_INTERFACE           0x0A
#define SET_INTERFACE           0x0B
#define SYNCH_FRAME             0x0C

//****************************************************************************************
// STANDARD USB REQUEST BIT MAP
//****************************************************************************************
#define bmRequestType           0x00
#define bRequest                0x01
#define wValue                  0x02
#define wValueHigh              0x03
#define wIndex                  0x04
#define wIndexHigh              0x05
#define wLength                 0x06
#define wLengthHigh             0x07

//****************************************************************************************
// GET_STATUS REQUEST RECIPIENTS
//****************************************************************************************
#define RECIPIENT_DEVICE        0x00
#define RECIPIENT_INTERFACE     0x01
#define RECIPIENT_ENDPOINT      0x02

//****************************************************************************************
// STANDARD DESCRIPTOR TYPES
//****************************************************************************************
#define DEVICE                  0x01
#define CONFIGURATION           0x02
#define STRING                  0x03
#define INTERFACE               0x04
#define ENDPOINT                0x05

//****************************************************************************************
// DESCRIPTOR TABLE OFFSETS
//****************************************************************************************
#define	NUM_CONFIGURATIONS      0x01
#define	NUM_INTERFACES          0x01

//****************************************************************************************
// STANDARD FEATURE SELECTORS
//****************************************************************************************
#define DEVICE_REMOTE_WAKEUP    0x01
#define ENDPOINT_HALT           0x00
#define TEST_MODE               0x02

//****************************************************************************************
// HID CLASS REQUESTS
//****************************************************************************************
#define GET_REPORT              0x01
#define GET_IDLE                0x02
#define SET_REPORT              0x09
#define SET_IDLE                0x0A

//****************************************************************************************
// HID CLASS DESCRIPTOR TYPES
//****************************************************************************************
#define HID                     0x21
#define REPORT                  0x22
#define PHYSICAL                0x23

//****************************************************************************************
// HID CLASS REPORT TYPES
//****************************************************************************************
#define INPUT                   0x01
#define OUTPUT                  0x02
#define FEATURE                 0x03

//**************************************************************
//place function prototypes here
//**************************************************************

void usb_isr(void);
void usb_error(void);
void usb_reset(void);
void usb_token(void);
void usb_token_setup(void);
void usb_in_token(void);
void usb_out_token(void);
void usb_request_error(void);
void usb_standard_request(void);
void usb_class_request(void);
void usb_set_feature_report(unsigned char);
void usb_interrupt_out_token(unsigned char);
void usb_detect(void);
void setup_usb(void);

#endif
