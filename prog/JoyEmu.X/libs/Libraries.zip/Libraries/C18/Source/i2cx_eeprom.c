
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 3                                              $:  Revision of last commit
//  $Author:: reneleonrichard                             $:  Author of last commit
//  $Date:: 2011-07-27 17:54:46 -0400 (Wed, 27 Jul 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Source/i2cx_eeprom.c $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************

#include <i2cx_eeprom.h>
#include <GenericTypeDefs.h>
#include <i2c.h>

//**************************************************************
//static constants
//**************************************************************
#pragma romdata

//**************************************************************
//unitialized variables
//**************************************************************
#pragma udata

struct i2c_eeprom_config{
	BYTE  control[8];
	BYTE  page_size[8];
	BYTE  status[8];
#if defined ( __18F66J50_H )
	BYTE  bus[8];   	//for multiple peripheral devices
#endif
};
struct i2c_eeprom_config eeprom;


//**************************************************************
//place initialized variables here
//**************************************************************
#pragma idata

//**************************************************************
//internal function prototypes here
//**************************************************************


//**************************************************************
//All code below this line should be functions only
#pragma code

//**************************************************************
//SUPPORTING FUNCTIONS START HERE
//**************************************************************
//FUNCTION NAME:    i2c_eeprom_close
//ARGUMENTS:        BYTE id - which eeprom to target
//RETURNS:          returns EEPROM_CLOSED or EEPROM_NOT_FOUND
//DESCRIPTION:      closes the corresponding eeprom
//**************************************************************
BYTE i2c_eeprom_close(BYTE id){
	
	BYTE result = EEPROM_CLOSED;
	
	eeprom.status[id] = EEPROM_CLOSED;	
	eeprom.page_size[id] = 0;
	eeprom.control[id] = 0;
#if defined ( __18F66J50_H )
	eeprom.bus[id] = I2C_NONE;
#endif
}

//**************************************************************
//FUNCTION NAME:    i2c_eeprom_open
//ARGUMENTS:        BYTE id - which eeprom to target
//					BYTE bus - which i2c bus to target --only on multiple I2C devices
//					BYTE address - i2c address 7bit left justified
//					BYTE page_size - size of write page size
//RETURNS:          returns EEPROM_FOUND or EEPROM_NOT_FOUND
//DESCRIPTION:      opens the corresponding eeprom, cheaply overloaded!
//**************************************************************
#if defined ( __18F66J50_H )
BYTE i2c_eeprom_open(BYTE id, BYTE bus, BYTE control, BYTE page_size){

	BYTE result = EEPROM_FOUND;

	if(id >= EEPROM_NUMBER){
		result = EEPROM_MAXED;
	}else{
		eeprom.control[id] = control & 0xFE;
		eeprom.page_size[id] = page_size;
		eeprom.bus[id] = bus;

		switch(eeprom.bus[id]){
			case I2C_1:
				StartI2C1();
				if ( (WriteI2C1(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					eeprom.status[id] = EEPROM_OPEN;
				}
				StopI2C1();
				break;
			case I2C_2:
				StartI2C2();
				if ( (WriteI2C2(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					eeprom.status[id] = EEPROM_OPEN;
				}
				StopI2C2();
				break;
			default:
				break;
		}
	}
	return result;
}
#elif defined ( __18F4620_H ) || defined ( __18F6720_H )
BYTE i2c_eeprom_open(BYTE id, BYTE control, BYTE page_size){

	BYTE result = EEPROM_FOUND;

	if(id >= EEPROM_NUMBER){
		result = EEPROM_MAXED;
	}else{
		eeprom.control[id] = control & 0xFE;
		eeprom.page_size[id] = page_size;

		StartI2C();
		if ( (WriteI2C(eeprom.control[id] | I2C_WRITE)) == NACK ){
			/* check if EEPROM acknowledged */
			result = EEPROM_NOT_ACK;
		}else{
			eeprom.status[id] = EEPROM_OPEN;
		}
		StopI2C();
	}
	return result;
}
#endif
//**************************************************************
//FUNCTION NAME:    init_eeprom_driver
//ARGUMENTS:        void
//RETURNS:          void
//DESCRIPTION:      initializes the eeprom driver
//**************************************************************
void i2c_eeprom_init_driver(void){

	BYTE i;

	for(i=0;i<EEPROM_NUMBER;i++){
		eeprom.status[i] = EEPROM_CLOSED;
	}
}

//**************************************************************
//FUNCTION NAME:    i2c_eeprom_read_byte
//ARGUMENTS:        BYTE id - id of eeprom as passed to i2c_open_eeprom()
//					WORD address - address of operation
//					BYTE *data - pointer to data
//RETURNS:          BYTE - returns result of operation:
//							EEPROM_SUCCESS
//							EEPROM_CLOSED
//							EEPROM_NOT_ACK
//DESCRIPTION:      initializes the eeprom driver
//**************************************************************
BYTE i2c_eeprom_read_byte(BYTE id, WORD address, BYTE *data){

	BYTE result = EEPROM_SUCCESS;

	/* check if corresponding eeprom has been opened */
	if(eeprom.status[id] == EEPROM_CLOSED){
		result = EEPROM_CLOSED;
	}else{
#if defined ( __18F66J50_H )
		switch(eeprom.bus[id]){
			case I2C_1:
				StartI2C1();
				if ( (WriteI2C1(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					WriteI2C1((BYTE)(address>>8));
					WriteI2C1((BYTE)address);
					RestartI2C1();
					WriteI2C1(eeprom.control[id] | I2C_READ);
					*data = ReadI2C1();
					NotAckI2C1();
				}
				StopI2C1();
				break;
			case I2C_2:
				StartI2C2();
				if ( (WriteI2C2(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					WriteI2C2((BYTE)(address>>8));
					WriteI2C2((BYTE)address);
					RestartI2C2();
					WriteI2C2(eeprom.control[id] | I2C_READ);
					*data = ReadI2C2();
					NotAckI2C2();
				}
				StopI2C2();
				break;
			default:
				break;
		}
#elif defined ( __18F4620_H ) || defined ( __18F6720_H )
		StartI2C();
		if ( (WriteI2C(eeprom.control[id] | I2C_WRITE)) == NACK ){
			/* check if EEPROM acknowledged */
			result = EEPROM_NOT_ACK;
		}else{
			WriteI2C((BYTE)(address>>8));
			WriteI2C((BYTE)address);
			RestartI2C();
			WriteI2C(eeprom.control[id] | I2C_READ);
			*data = ReadI2C();
			NotAckI2C();
		}
		StopI2C();
#endif
	}
	return result;
}

//**************************************************************
//FUNCTION NAME:    i2c_eeprom_read_length
//ARGUMENTS:        BYTE id - id of eeprom as passed to i2c_open_eeprom()
//					WORD address - address of operation
//					BYTE *data - pointer to data
//					BYTE length - length of data to read
//RETURNS:          BYTE - returns result of operation:
//							EEPROM_SUCCESS
//							EEPROM_CLOSED
//							EEPROM_NOT_ACK
//DESCRIPTION:      read up to 256 bytes of eeprom data
//**************************************************************
BYTE i2c_eeprom_read_length(BYTE id, WORD address, BYTE *data, BYTE length){

	BYTE result = EEPROM_SUCCESS;
	BYTE i;

	/* check if corresponding eeprom has been opened */
	if(eeprom.status[id] == EEPROM_CLOSED){
		result = EEPROM_CLOSED;
	}else{
#if defined ( __18F66J50_H )
		switch(eemprom.bus[id]){
			case I2C_1:
				StartI2C1();
				if ( (WriteI2C1(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					WriteI2C1((BYTE)(address>>8));
					WriteI2C1((BYTE)address);
					RestartI2C1();
					WriteI2C1(eeprom.control[id] | I2C_READ);
					for(i=0;i<(length-1);i++){
						*(data++) = ReadI2C1();
						AckI2C1();
					}
					*data = ReadI2C1();
					NotAckI2C1();
				}
				StopI2C1();
				break;
			case I2C_2:
				StartI2C2();
				if ( (WriteI2C2(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					WriteI2C2((BYTE)(address>>8));
					WriteI2C2((BYTE)address);
					RestartI2C2();
					WriteI2C2(eeprom.control[id] | I2C_READ);
					for(i=0;i<(length-1);i++){
						*(data++) = ReadI2C2();
						AckI2C2();
					}
					*data = ReadI2C2();
					NotAckI2C2();
				}
				StopI2C2();
				break;
			default:
				break;
		}
#elif defined ( __18F4620_H ) || defined ( __18F6720_H )
		StartI2C();
		if ( (WriteI2C(eeprom.control[id] | I2C_WRITE)) == NACK ){
			/* check if EEPROM acknowledged */
			result = EEPROM_NOT_ACK;
		}else{
			WriteI2C((BYTE)(address>>8));
			WriteI2C((BYTE)address);
			RestartI2C();
			WriteI2C(eeprom.control[id] | I2C_READ);
			for(i=0;i<(length-1);i++){
				*(data++) = ReadI2C();
				AckI2C();
			}
			*data = ReadI2C();
			NotAckI2C();
		}
		StopI2C();
#endif
	}
	return result;
}

//**************************************************************
//FUNCTION NAME:    i2c_eeprom_read_page
//ARGUMENTS:        BYTE id - id of eeprom as passed to i2c_open_eeprom()
//					WORD address - address of operation
//					BYTE *data - pointer to data
//RETURNS:          BYTE - returns result of operation:
//							EEPROM_SUCCESS
//							EEPROM_CLOSED
//							EEPROM_NOT_ACK
//DESCRIPTION:      initializes the eeprom driver
//**************************************************************
BYTE i2c_eeprom_read_page(BYTE id, WORD address, BYTE *data){

	BYTE i;
	BYTE result = EEPROM_SUCCESS;

	/* check if corresponding eeprom has been opened */
	if(eeprom.status[id] == EEPROM_CLOSED){
		result = EEPROM_CLOSED;
	}else{
#if defined ( __18F66J50_H )
		switch(eeprom.bus[id]){
			case I2C_1:
				StartI2C1();
				if ( (WriteI2C1(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					WriteI2C1((BYTE)(address>>8));
					WriteI2C1((BYTE)address);
					RestartI2C1();
					WriteI2C1(eeprom.control[id] | I2C_READ);
					for(i=0;i<(eeprom.page_size[id]-1);i++){
						*(data++) = ReadI2C1();
						AckI2C1();
					}
					*data = ReadI2C1();
				NotAckI2C1();
				}
				StopI2C1();
				break;
			case I2C_2:
				StartI2C2();
				if ( (WriteI2C2(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					WriteI2C2((BYTE)(address>>8));
					WriteI2C2((BYTE)address);
					RestartI2C2();
					WriteI2C2(eeprom.control[id] | I2C_READ);
					for(i=0;i<(eeprom.page_size[id]-1);i++){
						*(data++) = ReadI2C2();
						AckI2C2();
					}
					*data = ReadI2C2();
				NotAckI2C2();
				}
				StopI2C2();
				break;

			default:
				break;
		}
#elif defined ( __18F4620_H ) || defined ( __18F6720_H )
		StartI2C();
		if ( (WriteI2C(eeprom.control[id] | I2C_WRITE)) == NACK ){
			/* check if EEPROM acknowledged */
			result = EEPROM_NOT_ACK;
		}else{
			WriteI2C((BYTE)(address>>8));
			WriteI2C((BYTE)address);
			RestartI2C();
			WriteI2C(eeprom.control[id] | I2C_READ);
			for(i=0;i<(eeprom.page_size[id]-1);i++){
				*(data++) = ReadI2C();
				AckI2C();
			}
			*data = ReadI2C();
			NotAckI2C();
		}
		StopI2C();
#endif
	}
	return result;
}

//**************************************************************
//FUNCTION NAME:    i2c_eeprom_write_byte
//ARGUMENTS:        BYTE id - id of eeprom as passed to i2c_open_eeprom()
//					WORD address - address of operation
//					BYTE *data - pointer to data
//RETURNS:          BYTE - returns result of operation:
//							EEPROM_SUCCESS
//							EEPROM_CLOSED
//							EEPROM_NOT_ACK
//DESCRIPTION:      writes a byte of data to the EEPROM
//					this function does not loop until the write is done
//					code in main should be careful to check that the write
//					is complete before proceeding to other EEPROM tasks
//**************************************************************
BYTE i2c_eeprom_write_byte(BYTE id, WORD address, BYTE *data){

	BYTE result = EEPROM_SUCCESS;

	/* check if corresponding eeprom has been opened */
	if(eeprom.status[id] == EEPROM_CLOSED){
		result = EEPROM_CLOSED;
	}else{
#if defined ( __18F66J50_H )
		switch(eemprom.bus[id]){
			case I2C_1:
				StartI2C1();
				if ( (WriteI2C1(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					WriteI2C1((BYTE)(address>>8));
					WriteI2C1((BYTE)address);
					if( (WriteI2C1(*data)) == NACK ){
						result = EEPROM_NOT_ACK;
					}
				}
				StopI2C1();
				break;
			case I2C_2:
				StartI2C2();
				if ( (WriteI2C2(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					WriteI2C2((BYTE)(address>>8));
					WriteI2C2((BYTE)address);
					if( (WriteI2C2(*data)) == NACK ){
						result = EEPROM_NOT_ACK;
					}
				}
				StopI2C2();
				break;
			default:
				break;
		}
#elif defined ( __18F4620_H ) || defined ( __18F6720_H )
		StartI2C();
		if ( (WriteI2C(eeprom.control[id] | I2C_WRITE)) == NACK ){
			/* check if EEPROM acknowledged */
			result = EEPROM_NOT_ACK;
		}else{
			WriteI2C((BYTE)(address>>8));
			WriteI2C((BYTE)address);
			if( (WriteI2C(*data)) == NACK ){
				result = EEPROM_NOT_ACK;
			}
		}
		StopI2C();
#endif
	}
	return result;
}

//**************************************************************
//FUNCTION NAME:    i2c_eeprom_write_page
//ARGUMENTS:        BYTE id - id of eeprom as passed to i2c_open_eeprom()
//					WORD address - address of operation
//					BYTE *data - pointer to data
//RETURNS:          BYTE - returns result of operation:
//							EEPROM_SUCCESS
//							EEPROM_CLOSED
//							EEPROM_NOT_ACK
//DESCRIPTION:      writes a page of data to the EEPROM
//					this function does not loop until the write is done
//					code in main should be careful to check that the write
//					is complete before proceeding to other EEPROM tasks
//**************************************************************
BYTE i2c_eeprom_write_page(BYTE id, WORD address, BYTE *data){

	BYTE i;
	BYTE result = EEPROM_SUCCESS;

	/* check if corresponding eeprom has been opened */
	if(eeprom.status[id] == EEPROM_CLOSED){
		result = EEPROM_CLOSED;
	}else{
#if defined ( __18F66J50_H )
		switch(eeprom.bus[id]){
			case I2C_1:
				StartI2C1();
				if ( (WriteI2C1(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					WriteI2C1((BYTE)(address>>8));
					WriteI2C1((BYTE)address);
					for(i=0;i<eeprom.page_size[id];i++){
						if( (WriteI2C1(*(data++))) == NACK ){
							result = EEPROM_NOT_ACK;
							break;
						}
					}
				}
				StopI2C1();
				break;
			case I2C_2:
				StartI2C2();
				if ( (WriteI2C2(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					WriteI2C2((BYTE)(address>>8));
					WriteI2C2((BYTE)address);
					for(i=0;i<eeprom.page_size[id];i++){
						if( (WriteI2C2(*(data++))) == NACK ){
							result = EEPROM_NOT_ACK;
							break;
						}
					}
				}
				StopI2C2();
				break;
			default:
				break;
		}
#elif defined ( __18F4620_H ) || defined ( __18F6720_H )
		StartI2C();
		if ( (WriteI2C(eeprom.control[id] | I2C_WRITE)) == NACK ){
			/* check if EEPROM acknowledged */
			result = EEPROM_NOT_ACK;
		}else{
			WriteI2C((BYTE)(address>>8));
			WriteI2C((BYTE)address);
			for(i=0;i<eeprom.page_size[id];i++){
				if( (WriteI2C(*(data++))) == NACK ){
					result = EEPROM_NOT_ACK;
					break;
				}
			}
		}
		StopI2C();
#endif
	}
	return result;
}

//**************************************************************
//FUNCTION NAME:    i2c_eeprom_write_done
//ARGUMENTS:        BYTE id - id of eeprom as passed to i2c_open_eeprom()
//RETURNS:          BYTE - returns result of operation:
//							EEPROM_SUCCESS
//							EEPROM_CLOSED
//							EEPROM_NOT_ACK
//DESCRIPTION:      checks if the eeprom ACK's after a write sequence
//**************************************************************
BYTE i2c_eeprom_write_done(BYTE id){

	BYTE result = EEPROM_SUCCESS;

	/* check if corresponding eeprom has been opened */
	if(eeprom.status[id] == EEPROM_CLOSED){
		result = EEPROM_CLOSED;
	}else{
#if defined ( __18F66J50_H )
		switch(eeprom.bus[id]){
			case I2C_1:
				StartI2C1();
				if ( (WriteI2C1(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					StopI2C1();
				}
				break;
			case I2C_2:
				StartI2C2();
				if ( (WriteI2C2(eeprom.control[id] | I2C_WRITE)) == NACK ){
					/* check if EEPROM acknowledged */
					result = EEPROM_NOT_ACK;
				}else{
					StopI2C2();
				}
				break;
			default:
				break;
		}
#elif defined ( __18F4620_H ) || defined ( __18F6720_H )
		StartI2C();
		if ( (WriteI2C(eeprom.control[id] | I2C_WRITE)) == NACK ){
			/* check if EEPROM acknowledged */
			result = EEPROM_NOT_ACK;
		}else{
			StopI2C();
		}
#endif
	}
	return result;
}	

