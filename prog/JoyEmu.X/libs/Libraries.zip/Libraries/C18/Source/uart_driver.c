
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 23                                             $:  Revision of last commit
//  $Author:: rrichard                                    $:  Author of last commit
//  $Date:: 2011-08-05 13:06:57 -0400 (Fri, 05 Aug 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Source/uart_driver.c $
//
//*************************************************************
//defines, includes, enums here
//**************************************************************

#include <usart.h>
#include <uart_driver.h>


//**************************************************************
//static constants
//**************************************************************
#pragma romdata

//**************************************************************
//unitialized variables
//**************************************************************
#pragma udata

struct uart_buffer
{
	unsigned char data[UART_BUFFER_SIZE];
	unsigned char inptr;
	unsigned char outptr;
	unsigned char status;
};

static struct uart_buffer tx;
static struct uart_buffer rx;

//**************************************************************
//place initialized variables here
//**************************************************************
#pragma idata

//**************************************************************
//internal function prototypes here
//**************************************************************
static void pointer_mod(unsigned char *pointer, unsigned char cmd);

//**************************************************************
//All code below this line should be functions only
#pragma code

//**************************************************************
//SUPPORTING FUNCTIONS START HERE
//**************************************************************
//FUNCTION NAME:    uart_tx   
//ARGUMENTS:        unsigned char *data - pointer to data string
//					unsigned char *size - size of data string to add to txbuffer 
//RETURNS:          status of tx buffer
//DESCRIPTION:      puts data into the uart transmit queue
//**************************************************************
char uart_tx(char *data, unsigned char size)
{
	unsigned char i;

	/* check if data can fit in buffer, this doesn't check if the buffer's current
	   current pointers will allow (size) data to fit because it may be emptying 
	   concurrently through interupts */
	if (size > UART_BUFFER_SIZE){
		tx.status = UART_BUFFER_ERROR; 
	}else if(size == 0){
		/* null */
	}else{
		/* put data in trasmit buffer */
		for(i=0;i<size;i++){
			tx.data[tx.inptr] = *(data++);
			pointer_mod(&tx.inptr, INC);
			/* check for buffer full */
			if(tx.inptr == tx.outptr){
				tx.status = UART_BUFFER_FULL;
				/* return index value which caused buffer full */
				tx.status |= i;
				/* end for loop */
				break;
			}
		}
		/* initiate first tranfer, subsequent transfers are handled by interrupt */
		tx.status = UART_BUFFER_READY;
		WriteUSART(tx.data[tx.outptr]);
		pointer_mod(&tx.outptr,INC);
		/* enable tx interrupts */
		PIE1bits.TXIE = 1;
	}
	return tx.status;
}

//**************************************************************
//FUNCTION NAME:    uart_tx   
//ARGUMENTS:        unsigned char *data - pointer to data string
//					unsigned char *size - size of data string to add to txbuffer 
//RETURNS:          status of tx buffer
//DESCRIPTION:      puts data into the uart transmit queue
//**************************************************************
char uartROM_tx(const rom char *data, unsigned char size)
{
	unsigned char i;

	/* check if data can fit in buffer, this doesn't check if the buffer's current
	   current pointers will allow (size) data to fit because it may be emptying 
	   concurrently through interupts */
	if (size > UART_BUFFER_SIZE){
		tx.status = UART_BUFFER_ERROR; 
	}else if(size == 0){
		/* null */
	}else{
		/* put data in trasmit buffer */
		for(i=0;i<size;i++){
			tx.data[tx.inptr] = *(data++);
			pointer_mod(&tx.inptr, INC);
			/* check for buffer full */
			if(tx.inptr == tx.outptr){
				tx.status = UART_BUFFER_FULL;
				/* return index value which caused buffer full */
				tx.status |= i;
				/* end for loop */
				break;
			}
		}
		/* initiate first tranfer, subsequent transfers are handled by interrupt */
		tx.status = UART_BUFFER_READY;
		WriteUSART(tx.data[tx.outptr]);
		pointer_mod(&tx.outptr,INC);
		/* enable tx interrupts */
		PIE1bits.TXIE = 1;
	}
	return tx.status;
}

//**************************************************************
//FUNCTION NAME:    uart_rx   
//ARGUMENTS:        unsigned char *data - pointer to data string
//					unsigned char cmd - read or peak (peak doesn't empty buffer) 
//RETURNS:          unsigned char - size of data that was read
//DESCRIPTION:      reads or peaks the rx buffer
//**************************************************************
char uart_rx(char *data, unsigned char cmd)
{
	unsigned char size=0;
	unsigned char outptr = rx.outptr;

	/* read until buffer is empty */
	if(cmd == UART_READ){
		/* read with rx.outptr */
		while(!(rx.outptr == rx.inptr)){
			*(data++) = rx.data[outptr];
			pointer_mod(&rx.outptr,INC);
			rx.status = UART_BUFFER_READY;
			size++;
		}
		rx.status = UART_BUFFER_EMPTY;
	}else{
		/* read with outptr, don't affect any status or pointers */
		while(!(outptr == rx.inptr)){
			*(data++) = rx.data[outptr];
			pointer_mod(&outptr,INC);
			size++;
		}
	}
	return size;
}

//**************************************************************
//FUNCTION NAME:    pointer_mod   
//ARGUMENTS:        unsigned char *pointer - pointer to modulate
//					char INC - increment or decrement command
//RETURNS:          
//DESCRIPTION:      modulates the pointer according to UART_BUFFER_SIZE
//**************************************************************
static void pointer_mod(unsigned char *pointer, unsigned char cmd)
{
	if(cmd == INC){
		(*pointer)++;
	}else{
		(*pointer)--;
	}
	(*pointer) &= (unsigned char)(UART_BUFFER_SIZE-1);
}

//**************************************************************
//FUNCTION NAME:    init_uart   
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      initializes the uart interrupts and associated buffers
//**************************************************************
void initUARTDriver(char baudHighnLow, unsigned int baudRate)
{
	/* initialize tx and rx buffers */
	tx.inptr = 0;
	rx.inptr = 0;
	tx.outptr = 0;
	rx.outptr = 0;
	tx.status = UART_BUFFER_EMPTY;
	rx.status = UART_BUFFER_EMPTY;

	OpenUSART(USART_ASYNCH_MODE &
				USART_EIGHT_BIT &
				baudHighnLow,
				baudRate);

	/* clear interrupt flags */
	PIR1bits.RCIF = 0;
	PIR1bits.TXIF = 0;
	
	/* disable tx, enable rx interrupts, high priority */
	IPR1bits.TXIP = 1;
	IPR1bits.RCIP = 1;
	PIE1bits.RCIE = 1;
	PIE1bits.TXIE = 0;
}
//**************************************************************
//FUNCTION NAME:    uart_get_status   
//ARGUMENTS:        unsigned char rxtx -  
//RETURNS:          unsigned char - returns the buffer's status byte
//DESCRIPTION:      returns the rx or tx buffer's status byte
//**************************************************************
char uartGetStatus(unsigned char rxtx)
{
	unsigned char status = tx.status;

	if(rxtx == UART_RX){
		status = rx.status;
	}
	return status;
}

//**************************************************************
//FUNCTION NAME:    uart_rx_callback   
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      handles the uart rx interrupts
//**************************************************************
void uart_rx_callback(void)
{
	unsigned char dummy;

	/* if buffer is full, read into dummy and set error in status */
	if(rx.status == UART_BUFFER_FULL){
		dummy = ReadUSART();
		rx.status = UART_BUFFER_ERROR;
	}else{
		rx.data[rx.inptr] = ReadUSART();
		pointer_mod(&rx.inptr, INC);
		rx.status = UART_BUFFER_READY;
		if(rx.outptr == rx.inptr){
			rx.status = UART_BUFFER_FULL;
		}
	}
}

//**************************************************************
//FUNCTION NAME:    uart_tx_callback   
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      handles the uart tx interrupts
//**************************************************************
void uart_tx_callback(void)
{
	/* check if all data in buffer has been transmitted */
	if(tx.outptr == tx.inptr){
		tx.status = UART_BUFFER_EMPTY;
		/* disable interrupts since buffer is empty */
		PIE1bits.TXIE = 0;
	}else if(tx.status == UART_BUFFER_READY){
		WriteUSART(tx.data[tx.outptr]);
		pointer_mod(&tx.outptr,INC);
	}
}