
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 81                                             $:  Revision of last commit
//  $Author:: rrichard                                    $:  Author of last commit
//  $Date:: 2011-12-15 15:26:39 -0500 (Thu, 15 Dec 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Source/i2c_eeprom_4x_24xx102x.c $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************

#include <i2c.h>
#include <i2c_eeprom.h>
#include <i2c_eeprom_4x_24xx102x.h>

//**************************************************************
//static constants
//**************************************************************
#pragma romdata

//**************************************************************
//unitialized variables
//**************************************************************
#pragma udata

//**************************************************************
//place initialized variables here
//**************************************************************
#pragma idata

//**************************************************************
//internal function prototypes here
//**************************************************************
char _findBlock(unsigned short long address);

//**************************************************************
//All code below this line should be functions only
#pragma code

//**************************************************************
//SUPPORTING FUNCTIONS START HERE
//**************************************************************
//FUNCTION NAME:    memoryWriteByte
//ARGUMENTS:        
//RETURNS:			         
//DESCRIPTION:      
//**************************************************************
char memoryWriteByte(unsigned short long address, char *data)
{
	char blockID;
	
	blockID = _findBlock(address);
	return i2cEepromWriteByte(blockID, (unsigned int)address, data);
}

//**************************************************************
//FUNCTION NAME:    memoryWriteString
//ARGUMENTS:        
//RETURNS:			         
//DESCRIPTION:      
//**************************************************************
char memoryWritePage(unsigned short long address, char *data)
{
	char blockID;
	
	blockID = _findBlock(address);
	return i2cEepromWriteString(blockID, ((unsigned int)address & PAGE_BOUNDARY), data, PAGE_SIZE);
}

//**************************************************************
//FUNCTION NAME:    memoryReadByte
//ARGUMENTS:        
//RETURNS:			         
//DESCRIPTION:      
//**************************************************************
char memoryReadByte(unsigned short long address, char *data)
{
	char blockID;
	
	blockID = _findBlock(address);
	return i2cEepromReadByte(blockID, (unsigned int)address, data);
}

//**************************************************************
//FUNCTION NAME:    memoryReadPage
//ARGUMENTS:        
//RETURNS:			         
//DESCRIPTION:      
//**************************************************************
char memoryReadPage(unsigned short long address, char *data, unsigned char size)
{
	char blockID;
	
	blockID = _findBlock(address);
	return i2cEepromReadString(blockID, ((unsigned int)address & PAGE_BOUNDARY), data, PAGE_SIZE);
}

//**************************************************************
//FUNCTION NAME:    memoryIsWriteDone
//ARGUMENTS:        
//RETURNS:			         
//DESCRIPTION:      
//**************************************************************
char memoryIsWriteDone(unsigned short long address)
{
	char blockID;
	
	blockID = _findBlock(address);
	return i2cEepromIsWriteDone(blockID);
}

//**************************************************************
//FUNCTION NAME:    _findBlock
//ARGUMENTS:        
//RETURNS:			         
//DESCRIPTION:      
//**************************************************************
static char _findBlock(unsigned short long address)
{
	union _addressBlockFind
	{
		struct
		{
			unsigned char lowByte;
			unsigned char midByte;
			unsigned char hiByte;
		}bytes;
		unsigned short long address24bit;
	} addressUnion;
	
	addressUnion.address24bit = address;
	
	switch(addressUnion.bytes.hiByte)
	{
		case 0:
			return BLOCK0_ID;
			break;
		case 1:
			return BLOCK1_ID;
			break;
		case 2:
			return BLOCK2_ID;
			break;
		case 3:
			return BLOCK3_ID;
			break;
		case 4:
			return BLOCK4_ID;
			break;
		case 5:
			return BLOCK5_ID;
			break;
		case 6:
			return BLOCK6_ID;
			break;
		case 7:
			return BLOCK7_ID;
			break;
		default:
			return BLOCK0_ID;
			break;
	}
}