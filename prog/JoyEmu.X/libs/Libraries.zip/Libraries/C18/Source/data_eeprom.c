
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 14                                             $:  Revision of last commit
//  $Author:: reneleonrichard                             $:  Author of last commit
//  $Date:: 2011-08-02 14:31:02 -0400 (Tue, 02 Aug 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Source/data_eeprom.c $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************

#include <p18cxxx.h>

#include <data_eeprom.h>



//**************************************************************
//static constants
//**************************************************************
#pragma romdata

//**************************************************************
//unitialized variables
//**************************************************************
#pragma udata


//**************************************************************
//place initialized variables here
//**************************************************************
#pragma idata

//**************************************************************
//internal function prototypes here
//**************************************************************


//**************************************************************
//All code below this line should be functions only
#pragma code

#if defined	( __18F4620_H ) || defined ( __18F2620_H )
//**************************************************************
//SUPPORTING FUNCTIONS START HERE
//**************************************************************
//FUNCTION NAME:    data_eeprom_read
//ARGUMENTS:        unsigned int address - address of byte to read in 1024 range
//RETURNS:          unsigned char - data read from eeprom array
//DESCRIPTION:      reads 1 byte from the internal data eeprom array
//**************************************************************
unsigned char data_eeprom_read(unsigned int address){

	EEADR = (unsigned char)address;
	EEADRH = (unsigned char)(address>>8);

	EECON1bits.EEPGD = 0;
	EECON1bits.CFGS = 0;
	EECON1bits.RD = 1;

	return EEDATA;
}


//**************************************************************
//FUNCTION NAME:    data_eeprom_write
//ARGUMENTS:        unsigned int address - address of byte to read in 1024 range
//					unsigned char data - data to write to eeprom array
//RETURNS:          void
//DESCRIPTION:      reads 1 byte from the internal data eeprom array
//**************************************************************
void data_eeprom_write(unsigned int address, unsigned char data){

	EEADR = (unsigned char)address;
	EEADRH = (unsigned char)(address>>8);
	EEDATA = data;
	
	EECON1bits.EEPGD = 0;
	EECON1bits.CFGS = 0;
	EECON1bits.WREN = 1;

	INTCONbits.GIE = 0;
	EECON2 = 0x55;
	EECON2 = 0xAA;
	EECON1bits.WR = 1;
	INTCONbits.GIE = 1;
}

#elif defined ( __18F1320_H ) || defined ( __18F14K22_H )
//**************************************************************
//FUNCTION NAME:    data_eeprom_read
//ARGUMENTS:        unsigned char address - address of byte to read in 256 range
//RETURNS:          unsigned char - data read from eeprom array
//DESCRIPTION:      reads 1 byte from the internal data eeprom array
//**************************************************************
unsigned char data_eeprom_read(unsigned char address){

	EEADR = address;

	EECON1bits.EEPGD = 0;
	EECON1bits.CFGS = 0;
	EECON1bits.RD = 1;

	return EEDATA;
}

//**************************************************************
//FUNCTION NAME:    data_eeprom_write
//ARGUMENTS:        unsigned char address - address of byte to read in 256 range
//					unsigned char data - data to write to eeprom array
//RETURNS:          void
//DESCRIPTION:      reads 1 byte from the internal data eeprom array
//**************************************************************
void data_eeprom_write(unsigned char address, unsigned char data){

	EEADR = address;
	EEDATA = data;
	
	EECON1bits.EEPGD = 0;
	EECON1bits.CFGS = 0;
	EECON1bits.WREN = 1;

	INTCONbits.GIE = 0;
	EECON2 = 0x55;
	EECON2 = 0xAA;
	EECON1bits.WR = 1;
	INTCONbits.GIE = 1;
}
#endif
//**************************************************************
//FUNCTION NAME:    data_eeprom_write_done
//ARGUMENTS:        void
//RETURNS:          unsigned char
//						WRITE_COMPLETE
//						WRITE_IN_PROGRESS
//						WRITE_ERROR
//DESCRIPTION:      checks if the data eeprom write cycle is complete
//**************************************************************
unsigned char data_eeprom_write_done(void){

	if( EECON1bits.WRERR == 1){
		return WRITE_ERROR;
	}else{
		if( EECON1bits.WR == 1 ){
			return WRITE_IN_PROGRESS;
		}else{
			return WRITE_COMPLETE;
		}
	}
}

