Libraries
=========

Various stuff used throughout
