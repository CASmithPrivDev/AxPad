
//
//  $Rev:: 14                                             $:  Revision of last commit
//  $Author:: reneleonrichard                             $:  Author of last commit
//  $Date:: 2011-08-02 14:31:02 -0400 (Tue, 02 Aug 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Source/init_p18f1330.c $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************
#include <p18f1330.h>
#include <timers.h>

//**************************************************************
//static constants
//**************************************************************
#pragma romdata

//**************************************************************
//unitialized variables
//**************************************************************
#pragma udata


//**************************************************************
//place initialized variables here
//**************************************************************
#pragma idata

//**************************************************************
//internal function prototypes here
//**************************************************************


//**************************************************************
//All code below this line should be functions only
#pragma code

//**************************************************************
//SUPPORTING FUNCTIONS START HERE
//**************************************************************
//**************************************************************
//FUNCTION NAME:     void init_device(void);   
//ARGUMENTS:         pointer to user's init function of signature
//					 void foo(void);
//RETURNS:           none
//DESCRIPTION:       initializes the PIC18F1330 for this application
//**************************************************************
void init_device(void (*_initFuncPtr)(void)){

	/* wait for internal oscillator ready */
	while(OSCCONbits.OSTS == 0);
	/* init internal oscillator control at 8MHz */
	OSCCON |= 0b01110000;
	/* wait for oscillator to stabilize at 8MHz */
	while(OSCCONbits.IOFS == 0);
	/* Enable PLL, FOSC will be 32MHz */
	OSCTUNEbits.PLLEN = 1;
	while(OSCCONbits.IOFS == 0);

	/* call user's init function if it is not null */
	if( _initFuncPtr != 0 ){
		(*_initFuncPtr)();
	}
		
	/* init timer0 for ticks */
	INTCON2bits.TMR0IP = 1;
	OpenTimer0(TIMER_INT_ON & T0_16BIT & T0_SOURCE_INT & T0_PS_1_1);
	INTCONbits.TMR0IE = 1;

	/* enable priority levels on interrupts */
	RCONbits.IPEN = 1;        
	INTCONbits.GIEH = 1;     
	INTCONbits.GIEL = 0;

	/* enable watchdog timer, timer period is programmed in configuration bits to ~500ms */
	WDTCONbits.SWDTEN = 1;
	ClrWdt();
}

//**************************************************************
//INTERRUPTS
//**************************************************************
