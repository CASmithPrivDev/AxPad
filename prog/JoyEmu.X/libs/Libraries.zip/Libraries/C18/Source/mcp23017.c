
/*                                .ssssssssss         `ssssssssss                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                                  -MMMMMMMMMN         .MMMMMMMMMM                                   
                 .-:/+//:-`       -MMMMMMMMMN         .MMMMMMMMMM        .-:////:-`                 
            `/ydNMMMMMMMMMMNds:`  -MMMMMMMMMN         .MMMMMMMMMM   `/sdNMMMMMMMMMMNds:`            
         `/dMMMMMMMMMMMMMMMMMMMNy-:MMMMMMMMMN         .MMMMMMMMMM`/hMMMMMMMMMMMMMMMMMMMNy:          
       `+NMMMMMMMMMMMMMMMMMMMMMMMMmMMMMMMMMMN         .MMMMMMMMMMmMMMMMMMMMMMMMMMMMMMMMMMMd:        
      -mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh.      
     /MMMMMMMMMMMMmy+/----:+smMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMds/:----/ohNMMMMMMMMMMMN-     
    /MMMMMMMMMMMy-            .oNMMMMMMMMMMMN         .MMMMMMMMMMMMm+`           `:hMMMMMMMMMMN-    
   .NMMMMMMMMMm-                .hMMMMMMMMMMN         .MMMMMMMMMMMs`                /NMMMMMMMMMd    
   sMMMMMMMMMm`                   hMMMMMMMMMN         .MMMMMMMMMMo                   -NMMMMMMMMM/   
   mMMMMMMMMM:                    `NMMMMMMMMN         .MMMMMMMMMd                     sMMMMMMMMMy   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMm   
  .MMMMMMMMMM                      dMMMMMMMMN         .MMMMMMMMMs                     :MMMMMMMMMN   
  `NMMMMMMMMM-                    `NMMMMMMMMN         .MMMMMMMMMh                     +MMMMMMMMMh   
   hMMMMMMMMMh                    oMMMMMMMMMN         .MMMMMMMMMM:                   .NMMMMMMMMM+   
   -MMMMMMMMMMy`                 +MMMMMMMMMMN         .MMMMMMMMMMN:                 .mMMMMMMMMMN`   
    oMMMMMMMMMMm+`             :dMMMMMMMMMMMN         .MMMMMMMMMMMMy.             `oNMMMMMMMMMM:    
     sMMMMMMMMMMMNy/.      .:omMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMdo-`     `-+hNMMMMMMMMMMN/     
      /NMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMNNNNNMMMMMMMMMMMMMMm-      
       `sMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN         .MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNo`       
         .sNMMMMMMMMMMMMMMMMMMMMNy+MMMMMMMMMN         .MMMMMMMMMM:hMMMMMMMMMMMMMMMMMMMMMm+`         
            :smMMMMMMMMMMMMMMNy/` -MMMMMMMMMN         .MMMMMMMMMM  `+hNMMMMMMMMMMMMMMdo-            
               `-/osyhhyys+:.     `----------          ----------      ./+syyhyyso/-                
                                                                                                    
*/
//*************************************************************
//
//  $Rev:: 79                                             $:  Revision of last commit
//  $Author:: rrichard                                    $:  Author of last commit
//  $Date:: 2011-12-14 14:14:42 -0500 (Wed, 14 Dec 2011)  $:  Date of last commit
//  $HeadURL: https://subversion.assembla.com/svn/db_repository/trunk/Libraries/C18/Source/mcp23017.c $
//
//**************************************************************
//defines, includes, enums here
//**************************************************************

//#include <p18f4620.h>

#include <i2c.h>
#include <mcp23017.h>

//**************************************************************
//static constants
//**************************************************************
#pragma romdata

//**************************************************************
//unitialized variables
//**************************************************************
#pragma udata


//**************************************************************
//place initialized variables here
//**************************************************************
#pragma idata

//**************************************************************
//internal function prototypes here
//**************************************************************

//**************************************************************
//All code below this line should be functions only
#pragma code

//**************************************************************
//SUPPORTING FUNCTIONS START HERE
//**************************************************************
//FUNCTION NAME:    mcp23017WriteByte
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
char mcp23017WriteByte(char devID, enum _MCP23017RegAddr regAddr, char *data)
{
	char result = 0;

	StartI2C();
	if ( (WriteI2C(devID | _MCP23017DeviceAddr | I2C_WRITE)) == NACK )
	{
		/* check if device acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C(regAddr);
		WriteI2C(*data);
	}
	StopI2C();

	return result;
}


//**************************************************************
//FUNCTION NAME:    mcp23017WriteString
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
char mcp23017WriteString(char devID, enum _MCP23017RegAddr regAddr, char *data, unsigned char size)
{
	char result = 0;
	char i;
	
	StartI2C();
	if ( (WriteI2C(devID | _MCP23017DeviceAddr | I2C_WRITE)) == NACK )
	{
		/* check if device acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C(regAddr);
		for(i=0;i<size;i++)
		{
			if( (WriteI2C(*(data++))) == NACK )
			{
				result = -1;
				break;
			}
		}
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    mcp23017WriteROMString
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
char mcp23017WriteROMString(char devID, enum _MCP23017RegAddr regAddr, const rom char *data, unsigned char size)
{
	char result = 0;
	char i;
	
	StartI2C();
	if ( (WriteI2C(devID | _MCP23017DeviceAddr | I2C_WRITE)) == NACK )
	{
		/* check if device acknowledged */
		result = -1;
	}else{
		result = 1;
		WriteI2C(regAddr);
		for(i=0;i<size;i++)
		{
			if( (WriteI2C(*(data++))) == NACK )
			{
				result = -1;
				break;
			}
		}
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    mcp23017ReadByte
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
char mcp23017ReadByte(char devID, enum _MCP23017RegAddr regAddr, char *data)
{
	char result = 0;

	StartI2C();
	if ( (WriteI2C(devID | _MCP23017DeviceAddr | I2C_WRITE)) == NACK )
	{
		/* check if device acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C(regAddr);
		RestartI2C();
		WriteI2C(devID | _MCP23017DeviceAddr | I2C_READ);
		*data = ReadI2C();
		NotAckI2C();
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    mcp23017ReadString
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
char mcp23017ReadString(char devID, enum _MCP23017RegAddr regAddr, char *data, unsigned char size)
{
	char result = 0;
	char i;
		
	StartI2C();
	if ( (WriteI2C(devID | _MCP23017DeviceAddr | I2C_WRITE)) == NACK )
	{
		/* check if device acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C(regAddr);
		RestartI2C();
		WriteI2C(devID | _MCP23017DeviceAddr | I2C_READ);
		for(i=0;i<(size-1);i++)
		{
			*(data++) = ReadI2C();
			AckI2C();
		}
		NotAckI2C();
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    mcp23017ReadPortA
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
char mcp23017ReadPortA(char devID, char *data);
{
	char result = 0;

	StartI2C();
	if ( (WriteI2C(devID | _MCP23017DeviceAddr | I2C_WRITE)) == NACK )
	{
		/* check if device acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C(GPIOA);
		RestartI2C();
		WriteI2C(devID | _MCP23017DeviceAddr | I2C_READ);
		*data = ReadI2C();
		NotAckI2C();
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    mcp23017ReadPortB
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
char mcp23017ReadPortB(char devID, char *data);
{
	char result = 0;

	StartI2C();
	if ( (WriteI2C(devID | _MCP23017DeviceAddr | I2C_WRITE)) == NACK )
	{
		/* check if device acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C(GPIOB);
		RestartI2C();
		WriteI2C(devID | _MCP23017DeviceAddr | I2C_READ);
		*data = ReadI2C();
		NotAckI2C();
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    mcp23017ReadPortAB
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
char mcp23017ReadPortAB(char devID, char *data);
{
	char result = 0;

	StartI2C();
	if ( (WriteI2C(devID | _MCP23017DeviceAddr | I2C_WRITE)) == NACK )
	{
		/* check if device acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C(GPIOA);
		RestartI2C();
		WriteI2C(devID | _MCP23017DeviceAddr | I2C_READ);
		*data = (char)ReadI2C();
		AckI2C();
		data++;
		*data = (char)ReadI2C();
		NotAckI2C();
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    mcp23017WritePortA
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
char mcp23017WritePortA(char devID, char *data);
{
	char result = 0;

	StartI2C();
	if ( (WriteI2C(devID | _MCP23017DeviceAddr | I2C_WRITE)) == NACK )
	{
		/* check if device acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C(GPIOA);
		WriteI2C(*data);
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    mcp23017WritePortB
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
char mcp23017WritePortB(char devID, char *data);
{
	char result = 0;

	StartI2C();
	if ( (WriteI2C(devID | _MCP23017DeviceAddr | I2C_WRITE)) == NACK )
	{
		/* check if device acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C(GPIOB);
		WriteI2C(*data);
	}
	StopI2C();

	return result;
}

//**************************************************************
//FUNCTION NAME:    mcp23017WritePortAB
//ARGUMENTS:        
//RETURNS:          
//DESCRIPTION:      
//**************************************************************
char mcp23017WritePortAB(char devID, char *data);
{
	char result = 0;

	StartI2C();
	if ( (WriteI2C(devID | _MCP23017DeviceAddr | I2C_WRITE)) == NACK )
	{
		/* check if device acknowledged */
		result = -1;
	}else
	{
		result = 1;
		WriteI2C(GPIOA);
		WriteI2C((char)*data);
		data++;
		WriteI2C((char)*data);
	}
	StopI2C();

	return result;
}